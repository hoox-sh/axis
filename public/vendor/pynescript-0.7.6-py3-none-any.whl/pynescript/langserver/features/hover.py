# Copyright (C) 2024-2026 jango_blockchained
#
# This file is part of pynescript.
#
# pynescript is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# pynescript is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with pynescript.  If not, see <https://www.gnu.org/licenses/>.
#
# SPDX-License-Identifier: AGPL-3.0-or-later

"""Hover — ``textDocument/hover`` for builtins, types, namespaces, and locals.

Public handler: :func:`handle_hover`. Resolves the identifier under the cursor
(and optional ``module.member`` form) in this order: namespace prefix, type /
qualifier, builtin metadata, user enums, user declarations, then
:data:`~pynescript.langserver.providers.completion_items.PINE_KEYWORDS`.
"""

from __future__ import annotations

import re

from typing import Any

from lsprotocol import types as lsp

from pynescript.ast import node as ast
from pynescript.langserver.analysis import Symbol
from pynescript.langserver.analysis import SymbolIndex
from pynescript.langserver.analysis import _builtin_return_type
from pynescript.langserver.analysis import _function_return_type
from pynescript.langserver.analysis import _type_expr_name
from pynescript.langserver.analysis import ensure_symbol_index
from pynescript.langserver.protocol.utils import get_identifier_segment_at_position
from pynescript.langserver.protocol.utils import in_comment_or_string
from pynescript.langserver.providers.builtin_metadata import get_builtin
from pynescript.langserver.providers.completion_items import PINE_KEYWORDS
from pynescript.langserver.providers.completion_items import collect_user_enums
from pynescript.langserver.providers.docs_card import format_docs_card
from pynescript.langserver.providers.docs_card import format_named_table
from pynescript.langserver.providers.docs_card import pine_v6_docs_link
from pynescript.langserver.providers.docs_card import pine_v6_docs_url


_KEYWORD_DOCS = dict(PINE_KEYWORDS)

_TYPE_DOCS: dict[str, str] = {
    "int": "Integer numeric value.",
    "float": "Floating-point numeric value.",
    "bool": "Boolean value (`true` or `false`).",
    "string": "Text value.",
    "color": "RGBA color value.",
    "array": "Ordered collection (`array.new<type>()`, `array.get`).",
    "matrix": "Two-dimensional collection (`matrix.new<type>()`).",
    "map": "Key/value collection (`map.new<key, value>()`).",
    "line": "Drawing line object (`line.new`).",
    "linefill": "Fill between two lines (`linefill.new`, `line.fill`).",
    "label": "Drawing label object (`label.new`).",
    "box": "Drawing box object (`box.new`).",
    "table": "Drawing table object (`table.new`).",
    "polyline": "Multi-point drawing object (`polyline.new`).",
}

_QUALIFIER_DOCS: dict[str, str] = {
    "series": "The value may change from bar to bar.",
    "simple": "The value is fixed for a script execution (not bar-to-bar).",
    "const": "The value is known at compile time.",
    "input": "The value comes from a script input.",
    "var": "Initialized once and kept across bars.",
    "varip": "Like `var`, but also updates on every intra-bar tick.",
}

_MODE_QUALIFIERS = frozenset({"var", "varip"})

# Built-in variables are not callables, so they are absent from the function
# metadata catalog. Keep a small authoritative table for hover.
_BUILTIN_VAR_DOCS: dict[str, tuple[str, str]] = {
    "open": ("series float", "Open price of the current bar."),
    "high": ("series float", "High price of the current bar."),
    "low": ("series float", "Low price of the current bar."),
    "close": ("series float", "Close price of the current bar."),
    "volume": ("series float", "Volume of the current bar."),
    "hl2": ("series float", "Midpoint of the current bar's high and low."),
    "hlc3": ("series float", "Average of the current bar's high, low, and close."),
    "ohlc4": ("series float", "Average of the current bar's open, high, low, and close."),
    "time": ("series int", "UNIX timestamp (milliseconds) of the current bar's open."),
    "time_close": ("series int", "UNIX timestamp (milliseconds) of the current bar's close."),
    "bar_index": ("series int", "Zero-based index of the current bar."),
    "last_bar_index": ("series int", "Index of the last bar in the dataset."),
    "na": ("na", "Pine's missing-value literal."),
    "timenow": ("series int", "Current time as a UNIX timestamp in milliseconds."),
    "year": ("series int", "Year of the current bar's open time, in the exchange time zone."),
    "month": ("series int", "Month of the current bar's open time (1–12)."),
    "weekofyear": ("series int", "Week number of the current bar's open time."),
    "dayofmonth": ("series int", "Day of the month of the current bar's open time (1–31)."),
    "dayofweek": ("series int", "Day of the week of the current bar's open time (Sunday is 1)."),
    "hour": ("series int", "Hour of the current bar's open time (0–23)."),
    "minute": ("series int", "Minute of the current bar's open time (0–59)."),
    "second": ("series int", "Second of the current bar's open time (0–59)."),
}

# Exact Pine v6 parameter types for builtins whose metadata only lists names.
# Return types stay in ``_builtin_return_type`` so this table does not change inference.
_PARAM_TYPES: dict[str, dict[str, str]] = {
    "ta.sma": {"source": "series int/float", "length": "simple int"},
    "ta.ema": {"source": "series int/float", "length": "simple int"},
    "ta.rma": {"source": "series int/float", "length": "simple int"},
    "ta.wma": {"source": "series int/float", "length": "simple int"},
    "ta.vwma": {"source": "series int/float", "length": "simple int"},
    "ta.swma": {"source": "series int/float"},
    "ta.alma": {
        "series": "series int/float",
        "length": "simple int",
        "offset": "simple float",
        "sigma": "simple float",
    },
    "ta.rsi": {"source": "series int/float", "length": "simple int"},
    "ta.stoch": {
        "source": "series int/float",
        "high": "series int/float",
        "low": "series int/float",
        "length": "simple int",
    },
    "ta.cci": {"source": "series int/float", "length": "simple int"},
    "ta.mfi": {"series": "series int/float", "length": "simple int"},
    "ta.cmo": {"source": "series int/float", "length": "simple int"},
    "ta.cog": {"source": "series int/float", "length": "simple int"},
    "ta.atr": {"length": "simple int"},
    "ta.tr": {"handle_na": "simple bool"},
    "ta.macd": {
        "source": "series int/float",
        "fastlen": "simple int",
        "slowlen": "simple int",
        "siglen": "simple int",
    },
    "ta.bb": {"series": "series int/float", "length": "simple int", "mult": "simple float"},
    "ta.bbw": {"series": "series int/float", "length": "simple int", "mult": "simple float"},
    "ta.kc": {"series": "series int/float", "length": "simple int", "mult": "simple float"},
    "ta.kcw": {"series": "series int/float", "length": "simple int", "mult": "simple float"},
    "ta.crossover": {"source1": "series int/float", "source2": "series int/float"},
    "ta.crossunder": {"source1": "series int/float", "source2": "series int/float"},
    "ta.cross": {"source1": "series int/float", "source2": "series int/float"},
    "ta.change": {"source": "series int/float", "length": "simple int"},
    "ta.mom": {"source": "series int/float", "length": "simple int"},
    "ta.roc": {"source": "series int/float", "length": "simple int"},
    "ta.highest": {"source": "series int/float", "length": "simple int"},
    "ta.lowest": {"source": "series int/float", "length": "simple int"},
    "ta.highestbars": {"source": "series int/float", "length": "simple int"},
    "ta.lowestbars": {"source": "series int/float", "length": "simple int"},
    "ta.barssince": {"condition": "series bool"},
    "ta.valuewhen": {
        "condition": "series bool",
        "source": "series int/float",
        "occurrence": "simple int",
    },
    "ta.cum": {"source": "series int/float"},
    "ta.stdev": {"source": "series int/float", "length": "simple int"},
    "ta.variance": {"source": "series int/float", "length": "simple int"},
    "ta.correlation": {
        "source1": "series int/float",
        "source2": "series int/float",
        "length": "simple int",
    },
    "ta.percentrank": {"source": "series int/float", "length": "simple int"},
    "ta.rising": {"source": "series int/float", "length": "simple int"},
    "ta.falling": {"source": "series int/float", "length": "simple int"},
    "ta.pivothigh": {"source": "series int/float", "leftbars": "simple int", "rightbars": "simple int"},
    "ta.pivotlow": {"source": "series int/float", "leftbars": "simple int", "rightbars": "simple int"},
    "ta.supertrend": {"factor": "simple float", "atrPeriod": "simple int"},
    "ta.sar": {"start": "simple float", "inc": "simple float", "max": "simple float"},
    "ta.adx": {"diLength": "simple int", "adxSmoothing": "simple int"},
    "ta.dmi": {"diLength": "simple int", "adxSmoothing": "simple int"},
    "ta.linreg": {"source": "series int/float", "length": "simple int", "offset": "simple int"},
    "ta.vwap": {"source": "series int/float"},
    "ta.wpr": {"length": "simple int"},
    "math.abs": {"number": "series int/float"},
    "math.max": {"number0": "series int/float", "number1": "series int/float"},
    "math.min": {"number0": "series int/float", "number1": "series int/float"},
    "str.tostring": {"value": "series int/float/bool/string"},
    "str.length": {"string": "series string"},
    "color.new": {"color": "series color", "transp": "series int"},
    "color.rgb": {
        "red": "series int/float",
        "green": "series int/float",
        "blue": "series int/float",
        "transp": "series int",
    },
    "input.int": {"defval": "const int"},
    "input.float": {"defval": "const float"},
    "input.bool": {"defval": "const bool"},
    "input.string": {"defval": "const string"},
    "input.color": {"defval": "const color"},
    "input.source": {"defval": "series float"},
}

# Tuple results the ``ta.* → series float`` fallback would flatten.
_RETURN_OVERRIDES: dict[str, str] = {
    "ta.macd": "tuple[series float, series float, series float]",
    "ta.bb": "tuple[series float, series float, series float]",
    "ta.kc": "tuple[series float, series float, series float]",
    "ta.dmi": "tuple[series float, series float, series float]",
    "ta.supertrend": "tuple[series float, series float]",
    "ta.stoch": "series float",
    "ta.highestbars": "series int",
    "ta.lowestbars": "series int",
    "ta.barssince": "series int",
    "ta.crossover": "series bool",
    "ta.crossunder": "series bool",
    "ta.cross": "series bool",
    "ta.rising": "series bool",
    "ta.falling": "series bool",
    "math.abs": "series float",
    "str.tostring": "series string",
    "str.length": "series int",
    "color.new": "series color",
    "color.rgb": "series color",
}

_TYPE_FORMS: dict[str, str] = {
    "int": "`const int` · `input int` · `simple int` · `series int`",
    "float": "`const float` · `input float` · `simple float` · `series float`",
    "bool": "`const bool` · `input bool` · `simple bool` · `series bool`",
    "string": "`const string` · `input string` · `simple string` · `series string`",
    "color": "`const color` · `input color` · `simple color` · `series color`",
    "array": "`array<int>` · `array<float>` · `array<bool>` · `array<string>` · `array<color>`",
    "matrix": "`matrix<int>` · `matrix<float>` · `matrix<bool>` · `matrix<string>`",
    "map": "`map<string, float>` · `map<int, float>` · `map<string, string>`",
    "line": "`series line`",
    "linefill": "`series linefill`",
    "label": "`series label`",
    "box": "`series box`",
    "table": "`series table`",
    "polyline": "`series polyline`",
}

# Module names shown when the cursor is on the left of ``module.member``.
_NAMESPACE_DOCS: dict[str, str] = {
    "ta": "Technical-analysis functions (`ta.sma`, `ta.ema`, `ta.rsi`, …).",
    "math": "Mathematical functions (`math.abs`, `math.max`, `math.log`, …).",
    "str": "String helpers (`str.tostring`, `str.format`, …).",
    "strategy": "Strategy orders, positions, and properties.",
    "input": "Script input widgets (`input.int`, `input.float`, …).",
    "request": "Data requests from other contexts (`request.security`, …).",
    "color": "Color constants and helpers (`color.new`, `color.rgb`, `color.red`, …).",
    "array": "Array helpers (`array.new`, `array.get`, `array.push`, …).",
    "matrix": "Matrix helpers (`matrix.new`, `matrix.get`, …).",
    "map": "Map helpers (`map.new`, `map.get`, `map.put`, …).",
    "line": "Line drawings (`line.new`, `line.fill`, `line.set_xy1`, …).",
    "linefill": "Fill between two lines (`linefill.new`, `linefill.delete`, …).",
    "label": "Label drawings (`label.new`, `label.set_text`, …).",
    "box": "Box drawings (`box.new`, `box.set_bgcolor`, …).",
    "table": "Table drawings (`table.new`, `table.cell`, …).",
    "polyline": "Polyline drawings (`polyline.new`, `polyline.delete`, …).",
    "ticker": "Ticker constructors (`ticker.new`, `ticker.heikinashi`, …).",
    "timeframe": "Timeframe helpers (`timeframe.period`, `timeframe.change`, …).",
    "chart": "Chart context (`chart.bg_color`, `chart.point`, …).",
    "log": "Script log helpers (`log.info`, `log.warning`, `log.error`).",
    "alert": "Alert helpers (`alert()`, `alertcondition`, frequency constants).",
    "syminfo": "Symbol metadata (`syminfo.ticker`, `syminfo.tickerid`, …).",
    "barstate": "Bar-state flags (`barstate.islast`, `barstate.ishistory`, …).",
    "session": "Session helpers (`session.ismarket`, `session.regular`, …).",
}

_SNIPPET_PLACEHOLDER = re.compile(r"\$\{(\d+):([^}]+)\}|\$\{(\d+)\}|\$(\d+)")

# Known Pine library annotation tags. Any other ``//`` line inside an
# annotation block is Markdown continuation content.
_KNOWN_ANNOTATION_TAGS = frozenset(
    {
        "version",
        "description",
        "function",
        "returns",
        "type",
        "variable",
        "param",
        "field",
        "enum",
        "strategy_alert_message",
    }
)

# Tags whose content is the node's description (function / type / variable).
_DESCRIPTION_TAGS = frozenset({"function", "type", "variable", "description", "enum"})


def _split_annotation_tag(body: str) -> tuple[str, str] | None:
    """Parse ``@tag rest`` from a stripped comment line.

    Character scan instead of ``@\\s*([A-Za-z_]+)(?:\\s+(.*))?$`` so hover
    does not run a user-controlled regex (CodeQL ``py/polynomial-redos``).
    """
    if not body.startswith("@"):
        return None
    i = 1
    n = len(body)
    while i < n and body[i] in " \t":
        i += 1
    start = i
    while i < n and (("A" <= body[i] <= "Z") or ("a" <= body[i] <= "z") or body[i] == "_"):
        i += 1
    if i == start:
        return None
    return body[start:i], body[i:].lstrip(" \t")


def handle_hover(
    params: lsp.HoverParams,
    source: str | None,
    tree: Any | None = ...,
    cache: dict[str, Any] | None = None,
    analysis: SymbolIndex | None = None,
) -> lsp.Hover | None:
    """Return markdown hover for a symbol at the cursor, or ``None``.

    Args:
        params: Client hover params (document URI + position).
        source: Document text, or ``None``.
        tree: Pre-parsed AST from the workspace cache. Pass ``None`` when the
            workspace already failed to parse. Omit (default ``...``) to parse
            from *source*.
        cache: Optional per-document-version memo (the workspace
            ``feature_cache``). Caches the user-declaration walk — without it
            every hover re-walks the whole AST.
        analysis: Pre-built symbol index for *tree*.

    Returns:
        :class:`~lsprotocol.types.Hover` with docs, or ``None`` if the
        symbol is unknown / out of range.
    """
    position = params.position

    if not source:
        return None

    lines = source.split("\n")
    if position.line >= len(lines):
        return None

    if in_comment_or_string(source, position.line, position.character):
        return None

    line_text = lines[position.line]
    segment, seg_start, seg_end, word = get_identifier_segment_at_position(source, position.line, position.character)
    if not word:
        return None

    # Scope-aware symbols and members win over namespace/type/builtin cards so
    # a local variable named ``color`` or a UDT field is not described as a
    # builtin namespace.
    index = ensure_symbol_index(source, tree, analysis)
    if index is not None:
        member = index.member_at(position.line, position.character)
        if member is not None:
            if member.symbol is not None:
                return _build_symbol_hover(member.symbol, source, position.line, seg_start, seg_end, index)
            if member.kind == "constructor":
                return _build_constructor_hover(member, position.line, seg_start, seg_end)
            if member.builtin_name:
                builtin = _hover_builtin(member.builtin_name, line_text, seg_start, position.line, seg_end)
                if builtin is not None:
                    return builtin
        symbol = index.symbol_at(position.line, position.character)
        if symbol is not None:
            return _build_symbol_hover(symbol, source, position.line, seg_start, seg_end, index)

    ns_hover = _hover_namespace(segment, word, line_text, position.line, seg_start, seg_end)
    if ns_hover is not None:
        return ns_hover

    type_hover = _hover_type_or_qualifier(segment, line_text, seg_end, position.line, seg_start)
    if type_hover is not None:
        return type_hover

    # The library declaration is a builtin-shaped call; prefer a script-level
    # //@description card when one exists.
    resolved = _resolve_tree(source, tree)
    if word == "library":
        library_hover = _hover_library(word, resolved, source, position.line, seg_start, seg_end)
        if library_hover is not None:
            return library_hover

    # User enums get a richer member-aware card than the generic decl card.
    enums = collect_user_enums(resolved, source)
    enum_hover = _hover_user_enum(word, enums, position.line, seg_start, seg_end)
    if enum_hover is not None:
        return enum_hover

    decl_info = _lookup_user_decl(segment, resolved, source, cache)

    builtin_hover = _hover_builtin(word, line_text, seg_start, position.line, seg_end)
    if builtin_hover is not None:
        # User-defined functions/methods/types shadow builtin metadata so
        # library ``//@function`` docs render for colliding names (e.g. ``bb``).
        if decl_info is not None and decl_info.get("kind") in {"function", "method", "type"}:
            return _build_user_decl_hover(decl_info, position.line, seg_start, seg_end)
        return builtin_hover

    if decl_info is not None:
        return _build_user_decl_hover(decl_info, position.line, seg_start, seg_end)

    builtin_var = _BUILTIN_VAR_DOCS.get(segment)
    if builtin_var is not None and not _followed_by_paren(line_text, seg_end):
        type_label, brief = builtin_var
        return _markdown_hover(
            f"{segment}: {type_label}",
            brief,
            position.line,
            seg_start,
            seg_end,
            kind="variable",
        )

    return _hover_keyword(segment, position.line, seg_start, seg_end)


def _build_symbol_hover(
    symbol: Symbol,
    source: str,
    line: int,
    start: int,
    end: int,
    index: SymbolIndex | None = None,
) -> lsp.Hover:
    """Build a hover card for a symbol from the static analysis index."""
    if symbol.kind in {"enum", "enum_member"}:
        enum_name = symbol.container if symbol.kind == "enum_member" else symbol.name
        members = []
        # The symbol does not carry the enum body; walk the enum declaration.
        node = symbol.node
        if symbol.kind == "enum_member" and isinstance(symbol.scope.node, ast.EnumDef):
            node = symbol.scope.node
        if isinstance(node, ast.EnumDef):
            for stmt in node.body:
                if isinstance(stmt, ast.Assign) and isinstance(stmt.target, ast.Name):
                    members.append({"name": stmt.target.id, "value": None})
        enum_info = {
            "name": enum_name,
            "members": members,
            "export": symbol.export,
        }
        member = symbol.name if symbol.kind == "enum_member" else None
        return _build_enum_hover(enum_info, member=member, line=line, start=start, end=end)

    if symbol.kind in {"param", "import"}:
        annotations = list(symbol.annotations)
    else:
        comment_block = _extract_comment_block(source.split("\n"), getattr(symbol.node, "lineno", None))
        # The AST keeps only ``//@tag`` lines (not Markdown continuation
        # lines), so prefer the full source comment block when present.
        annotations = comment_block or list(symbol.annotations)
    signature = symbol.signature or symbol.name
    info: dict[str, Any] = {
        "kind": symbol.kind,
        "signature": signature,
        "annotations": annotations,
        "param_types": _param_types_of(symbol),
        "field_types": _field_types_of(symbol),
        "return_type": _symbol_return_type(symbol, index),
    }
    hover = _build_user_decl_hover(info, line, start, end)
    extra: list[str] = []
    if symbol.type_label and symbol.type_label not in signature:
        extra.append(f"**Type:** `{symbol.type_label}`")
    if symbol.container:
        extra.append(f"**Member of** `{symbol.container}`")
    if extra:
        content = hover.contents
        if isinstance(content, lsp.MarkupContent):
            content.value = content.value.rstrip() + "\n\n" + "\n\n".join(extra) + "\n"
    return hover


def _build_constructor_hover(
    member: Any,
    line: int,
    start: int,
    end: int,
) -> lsp.Hover:
    """Hover for ``Type.new(...)`` constructors."""
    node = getattr(member, "node", None)
    type_name = ""
    value = getattr(node, "value", None)
    if isinstance(value, ast.Name):
        type_name = value.id or ""
    signature = f"{type_name}.new(...)" if type_name else "new(...)"
    brief = f"Create a new `{type_name}` value." if type_name else "Create a new user-defined value."
    return _markdown_hover(signature, brief, line, start, end, kind="constructor")


def _followed_by_paren(line_text: str, end: int) -> bool:
    return line_text[end:].lstrip().startswith("(")


def _markdown_hover(
    fence: str,
    brief: str,
    line: int,
    start: int,
    end: int,
    *,
    kind: str = "",
    sections: list[str] | None = None,
    footer: str = "",
) -> lsp.Hover:
    return lsp.Hover(
        contents=lsp.MarkupContent(
            kind=lsp.MarkupKind.Markdown,
            value=format_docs_card(
                kind=kind,
                fence=fence,
                body=brief,
                sections=sections,
                footer=footer,
            ),
        ),
        range=lsp.Range(
            start=lsp.Position(line=line, character=start),
            end=lsp.Position(line=line, character=end),
        ),
    )


def _hover_namespace(
    segment: str,
    word: str,
    line_text: str,
    line: int,
    start: int,
    end: int,
) -> lsp.Hover | None:
    """Hover when the cursor is on a module name (`ta` in `ta.sma`)."""
    brief = _NAMESPACE_DOCS.get(segment)
    if brief is None:
        return None
    # ``syminfo.ticker`` has a member segment named ``ticker``; that is a
    # property, not the ticker namespace. Only the head segment can be a
    # namespace.
    if word != segment and not word.startswith(segment + "."):
        return None
    dotted = word.startswith(segment + ".") or (end < len(line_text) and line_text[end] == ".")
    if not dotted:
        # Bare `ta` / `math` still document the module. Types that share a
        # name (`line`, `array`, `color`) and callables (`strategy(`, `input(`)
        # fall through to type / builtin hover.
        if _followed_by_paren(line_text, end) or segment in _TYPE_DOCS or segment in ("strategy", "input"):
            return None
    return _markdown_hover(segment, brief, line, start, end, kind="namespace")


def _hover_type_or_qualifier(
    segment: str,
    line_text: str,
    end: int,
    line: int,
    start: int,
) -> lsp.Hover | None:
    """Hover for a type or qualifier that is not being called as a function."""
    if _followed_by_paren(line_text, end):
        return None
    if segment in _TYPE_DOCS:
        forms = _TYPE_FORMS.get(segment)
        sections = [f"**Forms** {forms}"] if forms else None
        return _markdown_hover(segment, _TYPE_DOCS[segment], line, start, end, kind="type", sections=sections)
    if segment in _QUALIFIER_DOCS:
        kind = "mode" if segment in _MODE_QUALIFIERS else "qualifier"
        return _markdown_hover(segment, _QUALIFIER_DOCS[segment], line, start, end, kind=kind)
    return None


def _lookup_user_decl(
    name: str,
    tree: Any | None,
    source: str,
    cache: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    """Return the collected declaration info for *name*, or ``None``."""
    if not name or tree is None:
        return None
    try:
        if cache is not None and "user_decls" in cache:
            decls = cache["user_decls"]
        else:
            decls = _collect_user_decls(tree, source)
            if cache is not None:
                cache["user_decls"] = decls
    except Exception:
        return None
    result = decls.get(name)
    return result if isinstance(result, dict) else None


def _strip_comment_prefix(line: str) -> str | None:
    """Return the text after ``//`` (one leading space removed), or ``None``.

    Trailing whitespace is preserved: Pine Markdown uses two trailing spaces to
    force a line break.
    """
    text = line.lstrip()
    if not text.startswith("//"):
        return None
    body = text[2:]
    if body.startswith(" "):
        body = body[1:]
    return body


def _extract_comment_block(lines: list[str], lineno: int | None) -> list[str]:
    """Return the contiguous ``//`` comment block immediately above *lineno*.

    Args:
        lines: Document text split by ``\\n``.
        lineno: 1-based declaration line, or ``None``.

    Returns:
        Raw comment lines (top-to-bottom), or ``[]`` when the line above the
        declaration is not a ``//`` comment.
    """
    if not lines or not lineno:
        return []
    idx = lineno - 2
    if idx < 0 or not lines[idx].lstrip().startswith("//"):
        return []
    start = idx
    while start > 0 and lines[start - 1].lstrip().startswith("//"):
        start -= 1
    return lines[start : idx + 1]


def _extract_comment_block_at(lines: list[str], idx: int) -> list[str]:
    """Return the contiguous ``//`` comment block containing line *idx*."""
    if not lines or idx < 0 or idx >= len(lines) or not lines[idx].lstrip().startswith("//"):
        return []
    start = idx
    while start > 0 and lines[start - 1].lstrip().startswith("//"):
        start -= 1
    end = idx
    while end + 1 < len(lines) and lines[end + 1].lstrip().startswith("//"):
        end += 1
    return lines[start : end + 1]


def _parse_annotation_entries(block: list[str] | None) -> list[tuple[str, str | None, str]]:
    """Parse a ``//`` comment block into ``(tag, name, content)`` entries.

    A known tag line starts a new entry (``@function``, ``@param name …``,
    ``@returns``, …); every following plain ``//`` line is Markdown
    continuation content for that tag. Markdown (headings, lists, code fences,
    blockquotes, tables, links, inline formatting, and two-space line breaks)
    is preserved verbatim so the hover renders it.

    Args:
        block: Raw comment lines (each starting with ``//``), or ``None``.

    Returns:
        Ordered ``(tag, name, content)`` entries. ``name`` is set for
        ``param`` / ``field``. Empty when the block has no known tag.
    """
    entries: list[list[Any]] = []
    current: list[Any] | None = None
    for raw in block or []:
        body = _strip_comment_prefix(raw)
        if body is None:
            continue
        parsed = _split_annotation_tag(body.lstrip())
        tag = parsed[0].lower() if parsed else ""
        if parsed and tag in _KNOWN_ANNOTATION_TAGS:
            if current is not None:
                entries.append(current)
            rest = parsed[1] or ""
            if tag in {"param", "field"}:
                parts = rest.split(None, 1)
                name = parts[0] if parts else ""
                desc = parts[1] if len(parts) > 1 else ""
                current = [tag, name, [desc] if desc else []]
            else:
                current = [tag, None, [rest] if rest else []]
        elif current is not None:
            current[2].append(body)
    if current is not None:
        entries.append(current)
    return [(entry[0], entry[1], "\n".join(entry[2]).rstrip("\n")) for entry in entries]


def _annotation_sections(
    entries: list[tuple[str, str | None, str]],
) -> tuple[str | None, list[tuple[str, str]], str | None, list[tuple[str, str]], list[str]]:
    """Split annotation entries into description, params, returns, fields, and notes.

    ``@function`` / ``@type`` / ``@variable`` / ``@enum`` is the card body.
    A separate ``@description`` is kept as a note when it is not that body.
    ``@version`` and ``@strategy_alert_message`` are notes too.
    """
    description: str | None = None
    extra_description: str | None = None
    returns: str | None = None
    params: list[tuple[str, str]] = []
    fields: list[tuple[str, str]] = []
    notes: list[str] = []
    for tag, field_name, content in entries:
        if tag in {"function", "type", "variable", "enum"} and content and description is None:
            description = content
        elif tag == "description" and content:
            extra_description = content
        elif tag == "param" and field_name:
            params.append((field_name, content))
        elif tag == "field" and field_name:
            fields.append((field_name, content))
        elif tag == "returns" and content:
            returns = content
        elif tag == "version" and content:
            notes.append(f"**Version** `{content}`")
        elif tag == "strategy_alert_message" and content:
            notes.append(f"**Alert message** {content}")
    if description is None and extra_description:
        description = extra_description
        extra_description = None
    if extra_description and extra_description != description:
        notes.insert(0, extra_description)
    return description, params, returns, fields, notes


def _split_leading_type(content: str) -> tuple[str, str]:
    """Split a leading ``(series float)`` annotation type from the prose."""
    match = _LEADING_ANNOT_TYPE.match((content or "").strip())
    if not match:
        return "", (content or "").strip()
    return match.group("typ").strip(), match.group("body").strip()


def _typed_rows(
    items: list[tuple[str, str]],
    known: dict[str, str] | None = None,
) -> list[tuple[str, str]]:
    """Merge annotation prose with an exact declared type."""
    rows: list[tuple[str, str]] = []
    seen: set[str] = set()
    types = known or {}
    for name, content in items:
        typ, desc = _split_leading_type(content)
        if not typ:
            typ, desc = _split_param_type(content)
        if not typ:
            typ = types.get(name, "")
        rows.append((name, _param_detail(typ, desc)))
        seen.add(name)
    for name, typ in types.items():
        if name and name not in seen and typ:
            rows.append((name, _param_detail(typ, "")))
    return rows


def _param_types_of(symbol: Symbol) -> dict[str, str]:
    """Declared parameter types on a function or method."""
    node = symbol.node
    if not isinstance(node, ast.FunctionDef):
        return {}
    found: dict[str, str] = {}
    for param in node.args or []:
        name = getattr(param, "name", None) or ""
        typ = _type_expr_name(getattr(param, "type", None)) or ""
        if name and typ:
            found[name] = typ
    return found


def _field_types_of(symbol: Symbol) -> dict[str, str]:
    """Declared field types on a user-defined type."""
    node = symbol.node
    if not isinstance(node, ast.TypeDef):
        return {}
    found: dict[str, str] = {}
    for stmt in node.body or []:
        if not isinstance(stmt, ast.Assign):
            continue
        typ = _type_expr_name(stmt.type) or ""
        target = stmt.target
        names = target.elts if isinstance(target, ast.Tuple) else [target]
        for item in names:
            if isinstance(item, ast.Name) and item.id and typ:
                found[item.id] = typ
    return found


def _symbol_return_type(symbol: Symbol, index: SymbolIndex | None) -> str | None:
    """Explicit or inferred return type for a function or method."""
    if symbol.type_label:
        return symbol.type_label
    if index is None or symbol.kind not in {"function", "method"}:
        return None
    inferred = _function_return_type(symbol, index)
    if inferred:
        return inferred
    node = symbol.node
    if not isinstance(node, ast.FunctionDef):
        return None
    body = node.body or []
    if len(body) != 1 or not isinstance(body[0], ast.Expr) or not isinstance(body[0].value, ast.Name):
        return None
    return _param_types_of(symbol).get(body[0].value.id or "") or None


def _format_named_list(title: str, items: list[tuple[str, str]]) -> str:
    """Render a Markdown table (or bullets) of ``name``/``description`` pairs."""
    return format_named_table(title, items)


def _build_user_decl_hover(info: dict[str, Any], line: int, start: int, end: int) -> lsp.Hover:
    """Build a Markdown hover card from a declaration's annotations.

    The card mirrors TradingView's library hover: a fenced signature, then the
    ``//@function`` / ``//@type`` / ``//@variable`` description rendered as
    Markdown, followed by ``//@field``, ``//@param``, and ``//@returns``
    sections. Without annotations it falls back to a one-line note.
    """
    kind = info.get("kind", "declaration")
    signature = str(info.get("signature") or info.get("name") or kind)
    entries = _parse_annotation_entries(info.get("annotations"))
    description, params, returns, fields, notes = _annotation_sections(entries)
    return_type = str(info.get("return_type") or "").strip()
    if return_type and f"→ {return_type}" not in signature:
        signature = f"{signature} → {return_type}"

    sections: list[str] = []
    sections.extend(notes)
    field_rows = _typed_rows(fields, info.get("field_types"))
    if field_rows:
        sections.append(_format_named_list("Fields", field_rows))
    param_rows = _typed_rows(params, info.get("param_types"))
    if param_rows:
        sections.append(_format_named_list("Parameters", param_rows))
    if returns:
        typ, desc = _split_leading_type(returns)
        if not typ:
            typ, desc = _split_param_type(returns)
        if typ:
            sections.append(f"**Returns:** `{typ}`" + (f" — {desc}" if desc else ""))
        else:
            sections.append(f"**Returns:** {returns}")
    elif return_type:
        sections.append(f"**Returns** `{return_type}`")
    body = description or (f"User-defined {kind}." if not sections else "")
    return lsp.Hover(
        contents=lsp.MarkupContent(
            kind=lsp.MarkupKind.Markdown,
            value=format_docs_card(
                kind=str(kind),
                fence=str(signature),
                body=body,
                sections=sections,
            ),
        ),
        range=lsp.Range(
            start=lsp.Position(line=line, character=start),
            end=lsp.Position(line=line, character=end),
        ),
    )


def _hover_library(
    word: str,
    tree: Any | None,
    source: str | None,
    line: int,
    start: int,
    end: int,
) -> lsp.Hover | None:
    """Hover the ``library`` declaration using the script-level ``//@description``."""
    if word != "library" or tree is None or not source:
        return None
    raw = getattr(tree, "annotations", None) or []
    if not any("description" in item for item in raw):
        return None
    lines = source.split("\n")
    for idx, text in enumerate(lines):
        if not re.match(r"^\s*//\s*@\s*description\b", text):
            continue
        entries = _parse_annotation_entries(_extract_comment_block_at(lines, idx))
        description = next(
            (content for tag, _name, content in entries if tag == "description" and content),
            None,
        )
        if description:
            return _markdown_hover("library", description, line, start, end, kind="library")
    return None


def _collect_user_decls(tree: Any, source: str) -> dict[str, dict[str, Any]]:
    """Map identifier → first declaration (kind, source signature, annotations)."""
    found: dict[str, dict[str, Any]] = {}
    # Split once — a per-declaration split is O(decls x doc-size).
    lines = source.split("\n") if source else []

    def add(name: str | None, kind: str, node: Any, fallback: str) -> None:
        if not name or name in found:
            return
        lineno = getattr(node, "lineno", None)
        snippet = _snippet_from_lines(lines, lineno)
        found[name] = {
            "kind": kind,
            "signature": snippet or fallback,
            # Full contiguous comment block (tag + Markdown continuation lines).
            "annotations": _extract_comment_block(lines, lineno),
        }

    def walk(node: Any) -> None:
        if node is None:
            return
        if isinstance(node, ast.FunctionDef) and node.name:
            kind = "method" if node.method else "function"
            add(node.name, kind, node, _function_fallback(node))
        elif isinstance(node, ast.TypeDef) and node.name:
            export = "export " if node.export else ""
            add(node.name, "type", node, f"{export}type {node.name}")
        elif isinstance(node, ast.EnumDef) and node.name:
            export = "export " if node.export else ""
            add(node.name, "enum", node, f"{export}enum {node.name}")
        elif isinstance(node, ast.Assign) and isinstance(node.target, ast.Name):
            add(node.target.id, "variable", node, node.target.id)
        elif isinstance(node, ast.Assign) and isinstance(node.target, ast.Tuple):
            for elt in node.target.elts or []:
                if isinstance(elt, ast.Name):
                    add(elt.id, "variable", node, elt.id)

        for field in getattr(node, "_fields", ()) or ():
            value = getattr(node, field, None)
            if value is None:
                continue
            if isinstance(value, list):
                for child in value:
                    if child is not None and hasattr(child, "_fields"):
                        walk(child)
            elif hasattr(value, "_fields"):
                walk(value)

    walk(tree)
    return found


def _function_fallback(node: ast.FunctionDef) -> str:
    args: list[str] = []
    for param in node.args or []:
        pname = getattr(param, "name", None)
        if pname:
            args.append(str(pname))
    prefix = ""
    if node.export:
        prefix += "export "
    if node.method:
        prefix += "method "
    return f"{prefix}{node.name}({', '.join(args)}) =>"


def _line_snippet(source: str, lineno: int | None) -> str:
    if not source or not lineno:
        return ""
    return _snippet_from_lines(source.split("\n"), lineno)


def _snippet_from_lines(lines: list[str], lineno: int | None) -> str:
    """Stripped source line *lineno* (1-based) from a pre-split line list."""
    if not lines or not lineno:
        return ""
    idx = lineno - 1
    if 0 <= idx < len(lines):
        return lines[idx].strip()
    return ""


def _hover_builtin(word: str, line_text: str, start: int, line: int, end: int) -> lsp.Hover | None:
    """Resolve a builtin from the full word, leaf, or preceding ``module.``."""
    called = _followed_by_paren(line_text, end)
    builtin_info = get_builtin(word)
    if builtin_info:
        return _build_builtin_hover(builtin_info, line, start, end, called=called)

    if "." in word:
        leaf = word.rsplit(".", 1)[-1]
        for candidate in (word, leaf):
            builtin_info = get_builtin(candidate)
            if builtin_info:
                return _build_builtin_hover(builtin_info, line, start, end, called=called)

    text_before = line_text[:start]
    words_before = text_before.rstrip().split()
    if words_before:
        last_word = words_before[-1]
        if last_word.endswith("."):
            module = last_word.rstrip(".")
            builtin_info = get_builtin(f"{module}.{word}")
            if builtin_info:
                return _build_builtin_hover(builtin_info, line, start, end, called=called)
    return None


def _resolve_tree(source: str | None, tree: Any | None) -> Any | None:
    if tree is not ...:
        return tree
    if not source:
        return None
    try:
        from pynescript.ast.helper import parse

        return parse(source)
    except Exception:
        return None


def _hover_user_enum(
    word: str,
    enums: dict[str, dict[str, Any]],
    line: int,
    start: int,
    end: int,
) -> lsp.Hover | None:
    """Hover for a user enum type or ``Enum.member`` path."""
    if word in enums:
        return _build_enum_hover(enums[word], member=None, line=line, start=start, end=end)
    if "." in word:
        enum_name, _, member = word.partition(".")
        info = enums.get(enum_name)
        if info is not None:
            return _build_enum_hover(info, member=member, line=line, start=start, end=end)
    return None


def _hover_keyword(word: str, line: int, start: int, end: int) -> lsp.Hover | None:
    brief = _KEYWORD_DOCS.get(word)
    if brief is None:
        return None
    return _markdown_hover(word, brief, line, start, end, kind="keyword")


def _build_enum_hover(
    info: dict[str, Any],
    member: str | None,
    line: int,
    start: int,
    end: int,
) -> lsp.Hover:
    name = info.get("name", "")
    export = "export " if info.get("export") else ""
    lines = [f"{export}enum {name}"]
    matched = None
    for item in info.get("members", []):
        mname = item.get("name", "")
        value = item.get("value")
        decl = f"    {mname}" if value is None else f"    {mname} = {value!r}"
        lines.append(decl)
        if member and mname == member:
            matched = item
    if member and matched is None:
        # Unknown member still shows the enum type.
        pass
    detail = "\n".join(lines)
    if member and matched is not None:
        value = matched.get("value")
        brief = f"Member of user enum `{name}`."
        if value is not None:
            brief += f" Value: `{value!r}`."
        kind = "member"
    else:
        brief = "User-defined enum."
        kind = "enum"
    return _markdown_hover(detail, brief, line, start, end, kind=kind)


def _signature_from_info(info: dict) -> str:
    """Prefer a real signature line; fall back to ``detail`` / label."""
    label = (info.get("label") or "").strip()
    detail = (info.get("detail") or "").strip()
    snippet = (info.get("snippet") or "").strip()
    if detail and not detail.endswith("(...)"):
        return detail
    if snippet:
        cleaned = _SNIPPET_PLACEHOLDER.sub(
            lambda m: m.group(2) if m.group(2) else "",
            snippet,
        )
        if cleaned and "param" not in cleaned.lower() and cleaned not in {label, f"{label}(...)"}:
            return cleaned
    return detail or label


def _known_param_types(label: str, facts: list[tuple[str, str, str]]) -> list[tuple[str, str, str]]:
    """Fill empty parameter types from the Pine v6 table."""
    known = _PARAM_TYPES.get(label, {})
    if not known:
        return facts
    filled: list[tuple[str, str, str]] = []
    for name, typ, desc in facts:
        filled.append((name, typ or known.get(name, ""), desc))
    return filled


_TYPE_WORDS = frozenset(
    {
        "series",
        "simple",
        "const",
        "input",
        "int",
        "float",
        "bool",
        "string",
        "color",
        "void",
        "line",
        "linefill",
        "label",
        "box",
        "table",
        "polyline",
        "array",
        "matrix",
        "map",
        "plot",
        "na",
    }
)


def _looks_like_type(value: str) -> bool:
    """True when *value* is a Pine type, not a sentence captured from a doc arrow."""
    text = (value or "").strip()
    if not text or "(" in text or ")" in text:
        return False
    if text.startswith("tuple[") and text.endswith("]"):
        return True
    words = text.replace(",", " ").split()
    if not words or len(words) > 4:
        return False
    for word in words:
        base = word.split("<", 1)[0].split("[", 1)[0]
        if base not in _TYPE_WORDS:
            return False
    return True


def _display_return_type(label: str) -> str:
    """Exact card return type. Does not affect the analyzer."""
    if label in _RETURN_OVERRIDES:
        return _RETURN_OVERRIDES[label]
    raw = _builtin_return_type(label) or ""
    return raw if _looks_like_type(raw) else ""


def _typed_builtin_signature(label: str, signature: str, facts: list[tuple[str, str, str]], return_type: str) -> str:
    """Prefer ``name(series float source, simple int length) → series float``."""
    if not any(typ for _name, typ, _desc in facts):
        if return_type and return_type not in signature and "→" not in signature:
            return f"{signature} → {return_type}"
        return signature
    args = ", ".join(f"{typ} {name}".strip() if typ else name for name, typ, _desc in facts)
    typed = f"{label}({args})" if label else signature
    if return_type and "→" not in typed:
        typed += f" → {return_type}"
    return typed


def _format_params(info: dict) -> str:
    """Render a Parameters section when metadata includes ``params``."""
    label = str(info.get("label") or "")
    rows: list[tuple[str, str]] = []
    for name, typ, desc in _known_param_types(label, builtin_param_facts(info)):
        rows.append((name, _param_detail(typ, desc)))
    if not rows:
        return ""
    return format_named_table("Parameters", rows)


def _build_builtin_hover(
    info: dict,
    line: int,
    start: int,
    end: int,
    *,
    called: bool = True,
) -> lsp.Hover:
    """Build a Hover for a builtin function or property.

    Args:
        info: Metadata dict from builtin_metadata.
        line: The line number (0-indexed).
        start: Start character position.
        end: End character position.
        called: Whether the identifier is followed by ``(``. Bare uses of
            overloaded entries (``syminfo.ticker``) get a property card rather
            than a function signature.

    Returns:
        LSP Hover with documentation.
    """
    label = info.get("label", "")
    signature = _signature_from_info(info)
    if called and "(" not in signature:
        signature = f"{label}(...)"
    if not called and "." in label and signature.startswith(label + "("):
        signature = label
    plain_signature = signature
    return_type = _display_return_type(label) if called or "(" in signature else ""
    facts = _known_param_types(label, builtin_param_facts(info)) if called else []
    if called:
        signature = _typed_builtin_signature(label, signature, facts, return_type)

    summary = builtin_card_summary(info, signature=plain_signature)
    if not summary and not called and "." in label:
        summary = "Built-in property."
    sections: list[str] = []
    if called:
        params_block = _format_params(info)
        if params_block:
            sections.append(params_block)
    doc_text = _public_builtin_prose(info, summary, plain_signature, label)
    if doc_text:
        sections.append(doc_text)
    examples = _build_examples(info)
    if examples:
        sections.append(examples)
    see_also = _build_see_also(info)
    if see_also:
        sections.append(see_also)
    kind = "function" if called or "(" in signature else "property"
    return _markdown_hover(
        signature,
        summary,
        line,
        start,
        end,
        kind=kind,
        sections=sections,
        footer=_build_docs_link(label),
    )


_DOC_LIMIT = 400


_SECTION_HEADERS = (
    "parameters:",
    "arguments:",
    "returns:",
    "example:",
    "examples:",
    "see also:",
    "fields:",
    "args:",
)

# Sentences that describe the host, not the Pine call. Drop them from cards.
_INTERNAL_RE = re.compile(
    r"context\[|data_provider|data_feed|ccxt|linter|corpus|subtask|pine-worker|"
    r"kwargs take precedence|internal color model|soft no-op|host bookkeeping|"
    r"process_pending_orders",
    re.IGNORECASE,
)

_LEADING_SIG_PHRASE = re.compile(r"(?is)^(signature|reference pine|pine script)\s*:?\s*`+[^`]*`+\s*")

_ARG_HEADERS = frozenset({"parameters", "parameter", "arguments", "args"})
_HEADER_LINE = re.compile(r"^[ \t]*([A-Za-z][A-Za-z ]{0,40}):\s*$")
_ARG_LINE = re.compile(r"^[ \t]+([A-Za-z_][A-Za-z0-9_]*)\s*:\s*(.*?)\s*$")
_TYPE_ATOM = (
    r"(?:series|simple|const|input|int|float|bool|string|str|color|void|"
    r"label|line|box|table|array|matrix|map|linefill|polyline|na|None)"
)
_TYPE_TAIL = re.compile(
    rf"^(?P<body>.*?)\s+\((?P<typ>{_TYPE_ATOM}(?:\s+{_TYPE_ATOM})?(?:\s+or\s+{_TYPE_ATOM})?)\)\s*$",
    re.IGNORECASE,
)
_TYPE_PHRASE = (
    r"(?:series|simple|const|input|int|float|bool|string|str|color|void|"
    r"label|line|box|table|array|matrix|map|linefill|polyline|na)"
    r"(?:\s+(?:int|float|bool|string|color))?"
    r"(?:/(?:int|float|bool|string))?"
)
_LEADING_ANNOT_TYPE = re.compile(
    rf"^\((?P<typ>{_TYPE_PHRASE})\)\s*(?P<body>.*)$",
    re.IGNORECASE | re.DOTALL,
)
_SIG_LINE = re.compile(r"(?is)^(signature|reference pine)\b")


def _strip_brief(
    documentation: str,
    brief: str,
    signature: str = "",
    label: str = "",
) -> str:
    """Drop documentation prefixes that repeat the brief, signature, or label.

    Builtin metadata often embeds a full signature plus a ``Parameters:`` block
    that the card already renders structurally. After removing the repeated
    prefixes, a leading section header means there is no extra prose to show.
    A bare label prefix does not eat the following call — ``name(args)`` is
    removed together so a property card does not keep a leftover ``(args)``.
    """
    doc = (documentation or "").strip()
    summary = (brief or "").strip()
    sig = (signature or "").strip()
    if not doc:
        return ""
    changed = True
    while changed and doc:
        changed = False
        for prefix in (summary, sig):
            if not prefix or not doc.startswith(prefix):
                continue
            rest = doc[len(prefix) :]
            if prefix == label:
                nxt = rest.lstrip(" \t")
                # ``strategy.entry creates…`` is prose. ``strategy.entry(…)``
                # is a call and is consumed below with its argument list.
                if nxt.startswith("(") or (nxt[:1].isalnum() or nxt[:1] == "_"):
                    continue
            doc = rest.lstrip(" .:—–-\n")
            changed = True
        # Some builtin docs start with their own call signature, e.g.
        # ``strategy.entry(id, direction, …) More detail.``.
        if label and doc.startswith(label):
            after = doc[len(label) :]
            if after.lstrip().startswith("("):
                open_index = doc.find("(", len(label))
                close_index = doc.find(")", open_index + 1)
                if close_index > open_index:
                    doc = doc[close_index + 1 :].lstrip(" .:—–-\n")
                    changed = True
        phrased = _LEADING_SIG_PHRASE.sub("", doc, count=1)
        if phrased != doc:
            doc = phrased.lstrip(" .:—–-\n")
            changed = True
        trimmed = _drop_leading_noise_line(doc, summary, sig, label)
        if trimmed != doc:
            doc = trimmed
            changed = True
    if doc.lower().startswith(_SECTION_HEADERS):
        return ""
    return "" if doc in {summary, sig} else doc


def _drop_leading_noise_line(doc: str, brief: str, signature: str, label: str) -> str:
    """Remove one leading line that only restates the signature or brief."""
    if not doc:
        return ""
    lines = doc.split("\n")
    first = lines[0].strip()
    if not first:
        return "\n".join(lines[1:]).strip()
    drop = (
        _is_signature_echo(first, label, signature)
        or _repeats_brief(first, brief)
        or _SIG_LINE.match(first) is not None
    )
    if not drop:
        return doc
    rest = lines[1:]
    while rest and (not rest[0].strip() or rest[0].startswith((" ", "\t"))):
        # Indented wrap of a ``Signature:`` line, or the blank line under it.
        if rest[0].strip() and not first.lower().startswith("signature"):
            break
        rest.pop(0)
    return "\n".join(rest).strip()


def _is_signature_echo(text: str, label: str, signature: str) -> bool:
    """True when *text* is only a label, call, or ``name / name(args)`` echo."""
    raw = (text or "").strip()
    if not raw:
        return True
    if raw in {label, signature, f"{label}(...)", f"{signature}."}:
        return True
    cleaned = re.sub(r"`[^`]*`", " ", raw)
    cleaned = re.sub(r"\([^)]*\)", " ", cleaned)
    for piece in sorted({p for p in (signature, label) if p}, key=len, reverse=True):
        cleaned = cleaned.replace(piece, " ")
    return re.sub(r"[^A-Za-z0-9]+", "", cleaned) == ""


def _repeats_brief(text: str, brief: str) -> bool:
    summary = (brief or "").strip()
    if not summary:
        return False
    cleaned = (text or "").replace("`", " ")
    cleaned = cleaned.replace(summary, " ")
    return re.sub(r"[^A-Za-z0-9]+", "", cleaned) == ""


def _balance_backticks(text: str) -> str:
    """Close an unclosed backtick run so later Markdown is not swallowed."""
    if not text or "`" not in text:
        return text
    i = 0
    n = len(text)
    while i < n:
        if text[i] != "`":
            i += 1
            continue
        j = i
        while j < n and text[j] == "`":
            j += 1
        run = j - i
        k = j
        closed = False
        while k < n:
            if text[k] != "`":
                k += 1
                continue
            m = k
            while m < n and text[m] == "`":
                m += 1
            if m - k == run:
                i = m
                closed = True
                break
            k = m
        if not closed:
            return text + ("`" * run)
    return text


def _one_sentence(text: str, limit: int = 220) -> str:
    """First sentence, clipped on a boundary. Empty when *text* is empty."""
    clean = " ".join((text or "").split())
    if not clean:
        return ""
    for index, ch in enumerate(clean):
        if ch in ".!?" and (index + 1 == len(clean) or clean[index + 1].isspace()):
            sentence = clean[: index + 1].strip()
            if len(sentence) <= limit:
                return sentence
            break
    return _truncate_text(clean, limit)


def _split_sentences(text: str) -> list[str]:
    clean = " ".join((text or "").split())
    if not clean:
        return []
    return [part for part in re.split(r"(?<=[.!?])\s+", clean) if part]


def _drop_internal_sentences(text: str) -> str:
    """Drop host-only sentences. Stop at the first fully internal paragraph."""
    kept: list[str] = []
    for para in (text or "").split("\n\n"):
        sentences = _split_sentences(para)
        if not sentences:
            continue
        good = [sentence for sentence in sentences if not _INTERNAL_RE.search(sentence)]
        if not good:
            break
        kept.append(" ".join(sentence.strip() for sentence in good))
    return "\n\n".join(kept).strip()


def builtin_card_summary(info: dict, *, signature: str | None = None) -> str:
    """One-paragraph summary for a builtin card.

    A brief that only restates the signature is replaced by the first public
    sentence of the documentation. Real briefs are kept as written.
    """
    label = (info.get("label") or "").strip()
    sig = signature if signature is not None else _signature_from_info(info)
    brief = _balance_backticks((info.get("brief") or "").strip())
    if brief and not _is_signature_echo(brief, label, sig):
        return brief
    prose = _strip_brief(info.get("documentation") or "", "", sig, label)
    prose = _drop_internal_sentences(prose)
    return _balance_backticks(_format_documentation(prose))


def _public_builtin_prose(info: dict, summary: str, signature: str, label: str) -> str:
    """Extra prose that does not repeat the summary, signature, or host notes."""
    raw = info.get("documentation") or ""
    prose = _strip_brief(raw, summary, signature, label)
    original = (info.get("brief") or "").strip()
    if original and original != summary:
        prose = _strip_brief(prose, original, signature, label)
    prose = _drop_internal_sentences(prose)
    text = _balance_backticks(_format_documentation(prose))
    if text and text[0].islower():
        text = text[0].upper() + text[1:]
    if not text or text == summary or _is_signature_echo(text, label, signature):
        return ""
    if _repeats_brief(text, summary):
        return ""
    return text


def _arg_descriptions(documentation: str) -> dict[str, str]:
    """Map parameter name → description from ``Parameters:`` / ``Args:`` blocks."""
    found: dict[str, str] = {}
    lines = (documentation or "").splitlines()
    index = 0
    while index < len(lines):
        header = _HEADER_LINE.match(lines[index])
        name = header.group(1).strip().lower() if header else ""
        if name not in _ARG_HEADERS:
            index += 1
            continue
        index += 1
        while index < len(lines):
            if not lines[index].strip():
                nxt = lines[index + 1] if index + 1 < len(lines) else ""
                if not nxt.startswith((" ", "\t")):
                    break
                index += 1
                continue
            if _HEADER_LINE.match(lines[index]) and not lines[index].startswith((" ", "\t")):
                break
            match = _ARG_LINE.match(lines[index])
            if not match:
                if not lines[index].startswith((" ", "\t")):
                    break
                index += 1
                continue
            key, desc = match.group(1), match.group(2).strip()
            index += 1
            extra: list[str] = []
            while index < len(lines) and lines[index].startswith((" ", "\t")) and not _ARG_LINE.match(lines[index]):
                if lines[index].strip():
                    extra.append(lines[index].strip())
                index += 1
            if extra:
                desc = (desc + " " + " ".join(extra)).strip()
            found[key] = desc
    return found


def _split_param_type(desc: str) -> tuple[str, str]:
    """Split a trailing Pine type ``(series float)`` from a parameter description."""
    match = _TYPE_TAIL.match((desc or "").strip())
    if not match:
        return "", (desc or "").strip()
    return match.group("typ"), match.group("body").strip()


def _param_detail(typ: str, desc: str) -> str:
    """Hover/signature detail: ``type`` · one sentence. Either piece may be empty."""
    sentence = _one_sentence(desc)
    bits: list[str] = []
    if typ:
        bits.append(f"`{typ}`")
    if sentence:
        bits.append(sentence)
    return " · ".join(bits)


def format_param_phrase(name: str, typ: str, desc: str) -> str:
    """Active-parameter line: name, the hover type, and at most one sentence."""
    detail = _param_detail(typ, desc)
    if not name:
        return detail
    if detail:
        return f"**`{name}`** — {detail}"
    return f"**`{name}`**"


def builtin_param_facts(info: dict) -> list[tuple[str, str, str]]:
    """``(name, type, description)`` in the same order and wording as hover."""
    documented = _arg_descriptions(info.get("documentation") or "")
    params = info.get("params")
    if params is None:
        params = info.get("parameters")
    facts: list[tuple[str, str, str]] = []
    if isinstance(params, dict):
        for key, value in params.items():
            desc = "" if value is None else str(value)
            if not desc:
                desc = documented.get(str(key), "")
            typ, desc = _split_param_type(desc)
            facts.append((str(key), typ, desc))
    elif isinstance(params, list):
        for item in params:
            if isinstance(item, str):
                typ, desc = _split_param_type(documented.get(item, ""))
                facts.append((item, typ, desc))
            elif isinstance(item, dict):
                name = str(item.get("name") or item.get("label") or "")
                if not name:
                    continue
                typ = str(item.get("type") or "")
                desc = str(item.get("brief") or item.get("documentation") or item.get("detail") or "")
                if not desc:
                    desc = documented.get(name, "")
                if not typ:
                    typ, desc = _split_param_type(desc)
                facts.append((name, typ, desc))
    cleaned: list[tuple[str, str, str]] = []
    for name, typ, desc in facts:
        text = desc.strip()
        if text.startswith("—"):
            text = text.lstrip("— ").strip()
        cleaned.append((name, typ.strip(), text))
    return cleaned


def lookup_param_fact(label: str, facts: list[tuple[str, str, str]]) -> tuple[str, str, str]:
    """Resolve a signature label to the hover fact for that parameter."""
    raw = (label or "").strip()
    base = raw.split("=", 1)[0].strip()
    parts = base.split()
    ident = parts[-1] if parts else base
    for name, typ, desc in facts:
        if name in {ident, base}:
            if not typ and len(parts) >= 2:
                return name, " ".join(parts[:-1]), desc
            return name, typ, desc
    typ = " ".join(parts[:-1]) if len(parts) >= 2 else ""
    return ident, typ, ""


def annotation_summary(lines: list[str] | None) -> str:
    """First sentence of a ``//@function`` / ``//@type`` description, if any."""
    description, _params, _returns, _fields, _notes = _annotation_sections(_parse_annotation_entries(lines))
    if not description:
        return ""
    return _one_sentence(description)


def _truncate_text(text: str, limit: int = _DOC_LIMIT) -> str:
    """Collapse whitespace and cut at a sentence boundary when possible."""
    clean = " ".join((text or "").split())
    if len(clean) <= limit:
        return clean
    window = clean[:limit]
    for separator in (". ", "! ", "? "):
        index = window.rfind(separator)
        if index >= limit // 2:
            return window[: index + 1].rstrip()
    index = window.rfind(" ")
    if index > 0:
        window = window[:index]
    return window.rstrip(" ,;:") + "…"


def _format_documentation(doc: str) -> str:
    """First paragraph, whitespace-collapsed, cut at a sentence boundary.

    A bullet list longer than :data:`_DOC_LIMIT` is omitted instead of chopped
    mid-list. Short prose still clips on a sentence boundary.
    """
    paragraphs = [part for part in (doc or "").split("\n\n") if part.strip()]
    if not paragraphs:
        return ""
    first_para = paragraphs[0]
    collapsed = " ".join(first_para.split())
    if len(collapsed) > _DOC_LIMIT and _is_bullet_wall(first_para):
        return ""
    return _truncate_text(first_para)


def _is_bullet_wall(text: str) -> bool:
    """True when *text* is a list, including a list already collapsed to one line."""
    collapsed = " ".join((text or "").split())
    return len(re.findall(r"(?:^|\s)[*•]\s", collapsed)) >= 2


def _build_examples(info: dict) -> str:
    """Build examples section for hover."""
    label = info.get("label", "")
    if not label.startswith(("ta.", "strategy.", "plot")):
        return ""

    examples = {
        "ta.sma": "```pinescript\nplot(ta.sma(close, 14))\n```",
        "ta.ema": "```pinescript\nplot(ta.ema(close, 14))\n```",
        "ta.rsi": "```pinescript\nplot(ta.rsi(close, 14))\n```",
        "ta.macd": "```pinescript\n[macdLine, signalLine, histLine] = ta.macd(close, 12, 26, 9)\nplot(macdLine, color=color.blue)\nplot(signalLine, color=color.orange)\n```",
        "strategy.entry": '```pinescript\nstrategy.entry("Long", strategy.long)\n```',
        "strategy.exit": '```pinescript\nstrategy.exit("Exit", profit=100, loss=50)\n```',
    }

    example = examples.get(label, "")
    if example:
        return f"**Example**\n\n{example}"
    return ""


def _build_see_also(info: dict) -> str:
    """Build 'See also' section."""
    related_map = {
        "ta.sma": ["ta.ema", "ta.rma", "ta.wma"],
        "ta.ema": ["ta.sma", "ta.rma", "ta.wma"],
        "ta.rsi": ["ta.stoch", "ta.mfi"],
        "ta.macd": ["ta.rsi", "ta.bb"],
        "ta.bb": ["ta.macd", "ta.kc"],
        "ta.atr": ["ta.tr"],
        "strategy.entry": ["strategy.exit", "strategy.close"],
    }

    label = info.get("label", "")
    related = related_map.get(label, [])

    if not related:
        return ""

    links: list[str] = []
    for name in related:
        url = pine_v6_docs_url(name)
        links.append(f"[`{name}`]({url})" if url else f"`{name}`")
    return f"**See also** {', '.join(links)}"


def _build_docs_link(name: str) -> str:
    """Markdown link to the public Pine v6 function reference.

    Only dotted builtin labels with a namespace (``ta.sma``,
    ``strategy.entry``, ``line.fill``) get a link. Empty, undotted
    (``sma``), or whitespace-only names return ``""``.
    """
    return pine_v6_docs_link(name)
