# Copyright (C) 2024-2026 jango_blockchained
#
# This file is part of pynescript.
#
# pynescript is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# pynescript is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with pynescript.  If not, see <https://www.gnu.org/licenses/>.
#
# SPDX-License-Identifier: AGPL-3.0-or-later

"""Definitions — ``textDocument/definition`` (go-to-definition).

Public handler: :func:`handle_definition`. Parses *source*, walks the AST with
:class:`DefinitionFinder`, and returns declaration locations for the word at
the cursor (same-document only).
"""

from __future__ import annotations

from typing import Any
from typing import cast

from lsprotocol import types as lsp

from pynescript.ast import NodeVisitor
from pynescript.ast import node as ast
from pynescript.langserver.analysis import Symbol
from pynescript.langserver.analysis import SymbolIndex
from pynescript.langserver.analysis import base_type_name
from pynescript.langserver.analysis import ensure_symbol_index
from pynescript.langserver.protocol.utils import in_comment_or_string


def handle_definition(
    params: lsp.DefinitionParams,
    source: str | None,
    uri: str,
    tree: Any | None = ...,
    *,
    analysis: SymbolIndex | None = None,
) -> list[lsp.Location] | None:
    """Find definition location(s) for the symbol under the cursor.

    Scope-aware: a local variable resolves to its own declaration rather than
    the first same-named assignment in the file. UDT fields/methods, enum
    members, parameters, and imports resolve through the static symbol index.

    Args:
        params: Client definition params (position).
        source: Document text, or ``None``.
        uri: Document URI for returned :class:`~lsprotocol.types.Location` objects.
        tree: Pre-parsed AST from the workspace cache. Pass ``None`` when the
            workspace already failed to parse (skips a redundant re-parse).
            Omit (default ``...``) to parse from *source*.
        analysis: Pre-built symbol index for *tree*.

    Returns:
        Non-empty list of locations, or ``None`` if unknown / unparsable.
    """
    if not source:
        return None
    line = params.position.line
    character = params.position.character
    if in_comment_or_string(source, line, character):
        return None

    index = ensure_symbol_index(source, tree, analysis)
    if index is None:
        return None

    symbol = index.symbol_at(line, character)
    if symbol is None:
        member = index.member_at(line, character)
        if member is not None and member.kind == "constructor":
            base = getattr(getattr(member.node, "value", None), "id", None)
            symbol = index.types.get(base) if base else None
    if symbol is None:
        return None

    declaration = _declaration_occurrence(index, symbol)
    if declaration is None:
        return None
    return [
        lsp.Location(
            uri=uri,
            range=lsp.Range(
                start=lsp.Position(line=declaration.line, character=declaration.column),
                end=lsp.Position(line=declaration.end_line, character=declaration.end_column),
            ),
        )
    ]


def handle_declaration(
    params: lsp.DeclarationParams,
    source: str | None,
    uri: str,
    tree: Any | None = ...,
    *,
    analysis: SymbolIndex | None = None,
) -> list[lsp.Location] | None:
    """Find declaration location(s) for the symbol under the cursor.

    Pine does not distinguish a declaration from a definition: ``x = 1``,
    ``f() =>``, and ``type T`` all declare their name at the same span. This
    delegates to :func:`handle_definition` so clients that ask for
    ``textDocument/declaration`` get the same scope-aware result.
    """
    return handle_definition(
        cast("lsp.DefinitionParams", params),
        source,
        uri,
        tree,
        analysis=analysis,
    )


def handle_type_definition(
    params: lsp.TypeDefinitionParams,
    source: str | None,
    uri: str,
    tree: Any | None = ...,
    *,
    analysis: SymbolIndex | None = None,
) -> list[lsp.Location] | None:
    """Resolve the user-defined type of the symbol under the cursor.

    Handles a variable whose value/annotation is a UDT, a UDT field, a
    parameter, and ``Type.new(...)``. Returns the ``type`` declaration only:
    builtin types (``series float``, ``array<float>``) have no source location.
    """
    if not source:
        return None
    line = params.position.line
    character = params.position.character
    if in_comment_or_string(source, line, character):
        return None

    index = ensure_symbol_index(source, tree, analysis)
    if index is None:
        return None

    type_label = _type_label_at(index, line, character)
    base = base_type_name(type_label)
    if not base:
        return None
    type_symbol = index.types.get(base)
    if type_symbol is None:
        return None

    declaration = _declaration_occurrence(index, type_symbol)
    if declaration is None:
        return None
    return [
        lsp.Location(
            uri=uri,
            range=lsp.Range(
                start=lsp.Position(line=declaration.line, character=declaration.column),
                end=lsp.Position(line=declaration.end_line, character=declaration.end_column),
            ),
        )
    ]


def _type_label_at(index: SymbolIndex, line: int, character: int) -> str | None:
    """Type label for the symbol/member at the cursor, or ``None``."""
    symbol = index.symbol_at(line, character)
    if symbol is not None:
        label = _symbol_type_label(index, symbol)
        if label:
            return label

    member = index.member_at(line, character)
    if member is None:
        return None
    if member.kind == "constructor":
        base = getattr(getattr(member.node, "value", None), "id", None)
        return base if isinstance(base, str) else None
    if member.symbol is not None:
        return _symbol_type_label(index, member.symbol)
    return None


def _symbol_type_label(index: SymbolIndex, symbol: Symbol) -> str | None:
    """Declared or inferred type label for *symbol*."""
    if symbol.kind in {"type", "enum"}:
        return symbol.name
    label = symbol.type_label
    if not label and symbol.kind == "variable" and isinstance(symbol.node, ast.Assign):
        label = index.infer_type(symbol.node.value, symbol.scope)
    return label


def _declaration_occurrence(index: SymbolIndex, symbol: Symbol) -> Any | None:
    occurrences = index.occurrences_for(symbol, include_declaration=True)
    if not occurrences:
        return None
    for occurrence in occurrences:
        if occurrence.node is symbol.name_node:
            return occurrence
    for occurrence in occurrences:
        if occurrence.write:
            return occurrence
    return occurrences[0]


class DefinitionFinder(NodeVisitor):
    """AST visitor that collects declaration locations for a single name.

    Populates :attr:`locations` for function/type defs and assignment targets
    matching *target_name*. Same-document only (uses *uri* for each location).
    """

    def __init__(self, target_name: str, uri: str) -> None:
        """Search for definitions of *target_name* in document *uri*."""
        super().__init__()
        self.target_name = target_name
        self.uri = uri
        self.locations: list[lsp.Location] = []
        self._seen_lines: set[int] = set()
        self.in_user_function: str | None = None
        self.in_user_type: str | None = None

    def visit_Script(self, node: ast.Script) -> Any:
        """Visit the root script node."""
        for stmt in node.body:
            self.visit(stmt)

    def visit_FunctionDef(self, node: ast.FunctionDef) -> Any:
        """Handle function definitions."""
        old_in_function = self.in_user_function
        if node.name == self.target_name:
            self._add_location(node.name, node.lineno)
        self.in_user_function = node.name
        for stmt in node.body:
            self.visit(stmt)
        self.in_user_function = old_in_function

    def visit_TypeDef(self, node: ast.TypeDef) -> Any:
        """Handle type (UDT) definitions."""
        old_in_type = self.in_user_type
        if node.name == self.target_name:
            self._add_location(node.name, node.lineno)
        self.in_user_type = node.name
        for stmt in node.body:
            self.visit(stmt)
        self.in_user_type = old_in_type

    def visit_EnumDef(self, node: ast.EnumDef) -> Any:
        """Handle enum type and member definitions."""
        if node.name == self.target_name:
            self._add_location(node.name, node.lineno)
        member = None
        if node.name and self.target_name.startswith(f"{node.name}."):
            member = self.target_name[len(node.name) + 1 :]
        for stmt in node.body:
            if isinstance(stmt, ast.Assign) and isinstance(stmt.target, ast.Name):
                if stmt.target.id == self.target_name or (member and stmt.target.id == member):
                    self._add_location(stmt.target.id, stmt.target.lineno)
            self.visit(stmt)

    def visit_Name(self, node: ast.Name) -> Any:
        """Handle variable references."""
        if node.id == self.target_name and node.ctx.__class__.__name__ == "Load":
            if self.in_user_function and self.in_user_function == self.target_name:
                return
            if self.in_user_type and self.in_user_type == self.target_name:
                return

            # Check if this is a definition (Store context)
            if hasattr(node, "_ctx") and node._ctx.__class__.__name__ == "Store":
                self._add_location(node.id, getattr(node, "lineno", None) or 0)
                return

    def visit_Assign(self, node: ast.Assign) -> Any:
        """Handle variable assignments."""
        # Check if the target matches
        if isinstance(node.target, ast.Name):
            if node.target.id == self.target_name:
                self._add_location(node.target.id, node.target.lineno)
                return

        for child in node.target._fields if hasattr(node.target, "_fields") else []:
            child_node = getattr(node.target, child, None)
            if isinstance(child_node, ast.Name) and child_node.id == self.target_name:
                self._add_location(child_node.id, child_node.lineno)

        if node.value is not None:
            self.visit(node.value)

    def visit_Call(self, node: ast.Call) -> Any:
        """Handle function calls."""
        if isinstance(node.func, ast.Name):
            if node.func.id == self.target_name:
                # This is a call, not a definition
                return
        for arg in node.args:
            self.visit(arg)

    def _add_location(self, name: str, lineno: int | None) -> None:
        """Add a definition location (deduped by line — O(1) per hit)."""
        if not lineno:
            lineno = 1

        line = max(0, lineno - 1)
        if line in self._seen_lines:
            return
        self._seen_lines.add(line)
        self.locations.append(
            lsp.Location(
                uri=self.uri,
                range=lsp.Range(
                    start=lsp.Position(line=line, character=0),
                    end=lsp.Position(line=line, character=0),
                ),
            )
        )
