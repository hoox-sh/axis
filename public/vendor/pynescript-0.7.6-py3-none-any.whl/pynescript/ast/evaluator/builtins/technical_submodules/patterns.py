# Copyright (C) 2024-2026 jango_blockchained
#
# This file is part of pynescript.
#
# pynescript is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# pynescript is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with pynescript.  If not, see <https://www.gnu.org/licenses/>.
#
# SPDX-License-Identifier: AGPL-3.0-or-later

"""Pattern-recognition ``ta.*`` indicators (SAR, engulfing, pivots, …).

Handlers are composed into
:class:`~pynescript.ast.evaluator.builtins.technical.TechnicalAnalysisMixin`.
"""

from __future__ import annotations

from typing import Any

from .core import TechnicalHelpers


class PatternIndicators(TechnicalHelpers):
    """Candlestick/price-pattern ``ta.*`` (SAR, engulfing, hammer, gap, pivots)."""

    # -- Public API (builtin_ta_ prefix) ------------------------------------

    def _builtin_ta_sar(self, args: list[Any]) -> list[float]:
        """Parabolic SAR (Stop and Reverse).

        ta.sar(high, low, start, increment, max)
        Trailing stop indicator.
        Returns SAR series.
        """
        msg = "ta.sar expects high, low, start, increment, max"
        self._require_len(args, 5, msg)  # QUINARY
        highs = self._expect_list(args[0], msg)
        lows = self._expect_list(args[1], msg)
        start = self._expect_number(args[2], msg)
        increment = self._expect_number(args[3], msg)
        maximum = self._expect_number(args[4], msg)
        return self._sar(highs, lows, start, increment, maximum)

    def _builtin_ta_engulfing(self, args: list[Any]) -> dict[str, int | bool]:
        """Engulfing Pattern Detector.

        ta.engulfing(open, high, low, close)
        Identifies bullish/bearish engulfing patterns.
        """
        if len(args) < 4:
            msg = "ta.engulfing() requires 4 arguments: open, high, low, close"
            self._error(msg)

        if self._use_incremental_ta():
            return self._engulfing_inc_update(
                self._as_series_or_raw(args[0], last_sample_ok=True),
                self._as_series_or_raw(args[3], last_sample_ok=True),
            )

        opens = self._as_series(args[0])
        closes = self._as_series(args[3])

        if len(opens) < 2 or len(closes) < 2:
            return {"is_bullish": False, "is_bearish": False, "pattern_strength": 0.0}

        return self._engulfing(opens, closes)

    def _builtin_ta_hammer(self, args: list[Any]) -> dict[str, bool | float]:
        """Hammer/Doji Pattern Detector.

        ta.hammer(open, high, low, close)
        Identifies hammer and doji patterns.
        """
        if len(args) < 4:
            msg = "ta.hammer() requires 4 arguments: open, high, low, close"
            self._error(msg)

        if self._use_incremental_ta():
            return self._hammer_inc_update(
                self._as_series_or_raw(args[0], last_sample_ok=True),
                self._as_series_or_raw(args[1], last_sample_ok=True),
                self._as_series_or_raw(args[2], last_sample_ok=True),
                self._as_series_or_raw(args[3], last_sample_ok=True),
            )

        opens = self._as_series(args[0])
        highs = self._as_series(args[1])
        lows = self._as_series(args[2])
        closes = self._as_series(args[3])

        if not opens or not closes:
            return {"is_hammer": False, "is_doji": False, "pattern_strength": 0.0}

        return self._hammer(opens, highs, lows, closes)

    def _builtin_ta_gap_detector(self, args: list[Any]) -> dict[str, float | int]:
        """Gap Pattern Detector.

        ta.gap_detector(high, low, prev_close)
        Identifies and measures price gaps.
        """
        if len(args) < 3:
            msg = "ta.gap_detector() requires 3 arguments: high, low, prev_close"
            self._error(msg)

        if self._use_incremental_ta():
            return self._gap_detector_inc_update(
                self._as_series_or_raw(args[0], last_sample_ok=True),
                self._as_series_or_raw(args[1], last_sample_ok=True),
                self._as_series_or_raw(args[2], last_sample_ok=True),
            )

        highs = self._as_series(args[0])
        lows = self._as_series(args[1])
        prev_close = float(args[2]) if isinstance(args[2], (int, float)) else None

        if not highs or not lows or prev_close is None:
            return {"gap_size": 0.0, "gap_type": 0, "gap_percent": 0.0}

        return self._gap_detector(highs, lows, prev_close)

    def _builtin_ta_fractal(self, args: list[Any]) -> dict[str, bool]:
        """Fractal Pattern Detector.

        ta.fractal(period)
        Identifies high/low fractals.
        """
        if len(args) < 1:
            msg = "ta.fractal() requires 1 argument: period"
            self._error(msg)

        period = self._expect_int(args[0], "period must be integer")

        if period < 1:
            msg = "Fractal period must be >= 1"
            self._error(msg)

        if self._use_incremental_ta():
            return self._fractal_inc_update(
                self._context_source("high"),
                self._context_source("low"),
                period,
            )

        highs = (getattr(self, "current_series", None) or {}).get("high", [])
        lows = (getattr(self, "current_series", None) or {}).get("low", [])

        if not highs or not lows or len(highs) < period * 2 + 1:
            return {"is_high_fractal": False, "is_low_fractal": False}

        # Check if current bar is a high fractal
        current_idx = len(highs) - 1
        is_high_fractal = highs[current_idx] == max(highs[current_idx - period : current_idx + period + 1])

        # Check if current bar is a low fractal
        is_low_fractal = lows[current_idx] == min(lows[current_idx - period : current_idx + period + 1])

        return {"is_high_fractal": is_high_fractal, "is_low_fractal": is_low_fractal}

    def _builtin_ta_double_top_bottom(self, args: list[Any]) -> dict[str, Any]:
        """Double Top/Bottom Pattern - Identifies classic reversal patterns.

        ta.double_top_bottom(high, low, period)
        Returns: {pattern_type, strength, breakout_level}.
        """
        if len(args) < 3:
            msg = "ta.double_top_bottom() requires 3 arguments"
            self._error(msg)

        period = self._expect_int(args[2], "period must be integer")

        if self._use_incremental_ta():
            return self._double_top_bottom_inc_update(
                self._as_series_or_raw(args[0], last_sample_ok=True),
                self._as_series_or_raw(args[1], last_sample_ok=True),
                period,
            )

        high_list = self._as_series(args[0])
        low_list = self._as_series(args[1])

        if len(high_list) < period or len(low_list) < period:
            return {"pattern_type": "none", "strength": 0.0, "breakout_level": 0.0}

        recent_high = [h for h in high_list[-period:] if isinstance(h, (int, float))]
        recent_low = [low_val for low_val in low_list[-period:] if isinstance(low_val, (int, float))]

        if len(recent_high) < 3:
            return {"pattern_type": "none", "strength": 0.0, "breakout_level": 0.0}

        peaks = [recent_high[0]]
        for i in range(1, len(recent_high) - 1):
            if recent_high[i] > recent_high[i - 1] and recent_high[i] > recent_high[i + 1]:
                peaks.append(recent_high[i])

        if len(peaks) >= 2:
            peak_diff = abs(peaks[-1] - peaks[-2])
            avg_peak = (peaks[-1] + peaks[-2]) / 2.0
            strength = 1.0 - min(1.0, peak_diff / avg_peak) if avg_peak > 0 else 0.0
            breakout_level = min(recent_low) - (avg_peak * 0.1)
            return {
                "pattern_type": "double_top",
                "strength": strength,
                "breakout_level": breakout_level,
            }

        return {"pattern_type": "none", "strength": 0.0, "breakout_level": 0.0}

    # -- Implementation helpers (private _method prefix) --------------------

    def _sar(
        self,
        highs: list[float],
        lows: list[float],
        start: float,
        increment: float,
        maximum: float,
    ) -> list[float]:
        """Calculate Parabolic SAR."""
        values, _ = self._sar_full(highs, lows, start, increment, maximum)
        return values

    def _sar_full(
        self,
        highs: list[float],
        lows: list[float],
        start: float,
        increment: float,
        maximum: float,
    ) -> tuple[list[float], int]:
        """Calculate Parabolic SAR with trend information (reference Pine).

        TradingView semantics (verified against the TV golden export):
        bar 0 is ``na``; bar 1 emits the seed (``low[0]``); from bar 2 on,
        Wilder's step with the SAR clamped to the previous two bars' extremes
        on non-reversal bars, EP/AF updated *before* the reversal check, and
        the reversal taken against the unclamped SAR (``sar = ep``).
        """
        if not highs or not lows:
            return [], 0
        # Skip leading na (empty series / warm-up)
        start_i = 0
        n = min(len(highs), len(lows))
        while start_i < n and (highs[start_i] is None or lows[start_i] is None):
            start_i += 1
        if start_i >= n:
            return [None] * n, 0
        sar_values: list[float | None] = [None] * n
        try:
            sar = float(lows[start_i])
            ep = float(highs[start_i])
        except (TypeError, ValueError):
            return sar_values, 0
        trend = 1
        af = float(start)
        seen = 1
        for idx in range(start_i + 1, n):
            hi, lo = highs[idx], lows[idx]
            if hi is None or lo is None:
                sar_values[idx] = sar_values[idx - 1]
                continue
            try:
                hi_f, lo_f = float(hi), float(lo)
            except (TypeError, ValueError):
                sar_values[idx] = sar_values[idx - 1]
                continue
            if seen < 2:
                # Second valid bar emits the seed value itself (no step).
                sar_values[idx] = sar
                seen = 2
                continue
            previous = sar
            sar = previous + af * (ep - previous)
            if trend == 1:
                if hi_f > ep:
                    ep = hi_f
                    af = min(af + increment, maximum)
                if lo_f < sar:
                    trend = -1
                    sar = ep
                    ep = lo_f
                    af = start
                else:
                    sar = min(sar, float(lows[idx - 1]), float(lows[idx - 2]))
            else:
                if lo_f < ep:
                    ep = lo_f
                    af = min(af + increment, maximum)
                if hi_f > sar:
                    trend = 1
                    sar = ep
                    ep = hi_f
                    af = start
                else:
                    sar = max(sar, float(highs[idx - 1]), float(highs[idx - 2]))
            sar_values[idx] = sar
        return sar_values, trend

    def _engulfing(
        self,
        opens: list[Any],
        closes: list[Any],
    ) -> dict[str, bool | float]:
        """Detect engulfing patterns."""
        current_open = opens[-1]
        current_close = closes[-1]

        prev_open = opens[-2]
        prev_close = closes[-2]

        # Bullish engulfing: current candle engulfs previous and is green
        is_bullish = current_open < prev_close and current_close > prev_open and current_close > current_open

        # Bearish engulfing: current candle engulfs previous and is red
        is_bearish = current_open > prev_close and current_close < prev_open and current_close < current_open

        # Pattern strength (0-1) based on how much body engulfed
        if is_bullish:
            engulf_amount = max(
                0,
                min(
                    1,
                    (current_close - prev_open) / abs(prev_open - prev_close + 0.0001),
                ),
            )
        elif is_bearish:
            engulf_amount = max(
                0,
                min(
                    1,
                    (prev_open - current_close) / abs(prev_close - prev_open + 0.0001),
                ),
            )
        else:
            engulf_amount = 0.0

        return {
            "is_bullish": is_bullish,
            "is_bearish": is_bearish,
            "pattern_strength": engulf_amount,
        }

    def _hammer(
        self,
        opens: list[Any],
        highs: list[Any],
        lows: list[Any],
        closes: list[Any],
    ) -> dict[str, bool | float]:
        """Detect hammer and doji patterns."""
        current_open = opens[-1]
        current_close = closes[-1]
        current_high = highs[-1]
        current_low = lows[-1]

        body_size = abs(current_close - current_open)
        total_range = current_high - current_low
        lower_wick = min(current_open, current_close) - current_low
        upper_wick = current_high - max(current_open, current_close)

        # Doji: open ~= close
        is_doji = body_size < total_range * 0.1

        # Hammer: small body, long lower wick, short upper wick
        is_hammer = body_size > 0 and lower_wick > body_size * 2 and upper_wick < body_size

        # Pattern strength
        if is_doji:
            strength = 1.0 - (body_size / (total_range + 0.0001))
        elif is_hammer:
            strength = min(1.0, lower_wick / (total_range + 0.0001))
        else:
            strength = 0.0

        return {
            "is_hammer": is_hammer,
            "is_doji": is_doji,
            "pattern_strength": strength,
        }

    def _gap_detector(
        self,
        highs: list[Any],
        lows: list[Any],
        prev_close: float,
    ) -> dict[str, float | int]:
        """Detect price gaps."""
        current_high = highs[-1]
        current_low = lows[-1]

        # Upside gap: current low > prev close
        upside_gap = max(0, current_low - prev_close)

        # Downside gap: current high < prev close
        downside_gap = max(0, prev_close - current_high)

        if upside_gap > downside_gap:
            gap_size = upside_gap
            gap_type = 1  # Upside
            gap_percent = (upside_gap / prev_close * 100) if prev_close != 0 else 0.0
        elif downside_gap > 0:
            gap_size = downside_gap
            gap_type = -1  # Downside
            gap_percent = (downside_gap / prev_close * 100) if prev_close != 0 else 0.0
        else:
            gap_size = 0.0
            gap_type = 0  # No gap
            gap_percent = 0.0

        return {
            "gap_size": gap_size,
            "gap_type": gap_type,
            "gap_percent": gap_percent,
        }
