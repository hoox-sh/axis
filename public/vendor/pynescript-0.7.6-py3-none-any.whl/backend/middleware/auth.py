# Copyright (C) 2024-2026 jango_blockchained
#
# This file is part of pynescript.
#
# pynescript is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# pynescript is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with pynescript.  If not, see <https://www.gnu.org/licenses/>.
#
# SPDX-License-Identifier: AGPL-3.0-or-later

"""API key authentication and usage tracking middleware.

Provides :class:`APIKey`, pluggable :class:`APIKeyStore` (JSON / SQLite /
Redis), and Flask decorators :func:`require_api_key`, :func:`track_usage`,
and :func:`require_admin_token`.
"""

from __future__ import annotations

import fcntl
import functools
import hashlib
import hmac
import json
import os
import secrets
import tempfile
import threading
import time

from dataclasses import dataclass
from dataclasses import field
from datetime import datetime
from datetime import timezone
from functools import wraps
from typing import Any
from typing import Protocol

from flask import g
from flask import jsonify
from flask import request


_HASH_SALT = b"pynescript-api-key-store"
_HASH_ITERATIONS = 100_000


@dataclass
class APIKey:
    """In-memory view of a hashed API key (tier, usage, limits).

    Raw secrets are never stored here after mint; only ``key_hash`` (and
    ``key_id`` for display) persist in backends.
    """

    key_id: str
    key_hash: str
    key_fingerprint: str = field(default="", repr=False, compare=False)
    tier: str = "free"
    calls_used: int = 0
    calls_limit: int | float = 0
    created_at: float = field(default_factory=time.time)
    last_used: float = 0.0
    # Set by the store so increment_calls can persist without the caller knowing
    # which backend is active.
    _store: Any = field(default=None, repr=False, compare=False)

    def is_active(self) -> bool:
        """Whether the key may be used (revocation hook; always true today)."""
        return True

    def calls_remaining(self) -> int | float:
        """Remaining monthly quota, or ``inf`` when unlimited."""
        if self.calls_limit == 0 or self.calls_limit == float("inf"):
            return float("inf")
        return max(0, self.calls_limit - self.calls_used)

    def is_rate_limited(self) -> bool:
        """True when the monthly call quota is exhausted."""
        if self.calls_limit == 0 or self.calls_limit == float("inf"):
            return False
        return self.calls_used >= self.calls_limit

    def get_tier_info(self) -> dict[str, Any]:
        """Public tier/usage snapshot for API responses."""
        return {
            "tier": self.tier,
            "calls_used": self.calls_used,
            "calls_limit": self.calls_limit if self.calls_limit != float("inf") else 0,
            "calls_remaining": self.calls_remaining(),
            "reset_at": self._get_reset_time(),
        }

    def _get_reset_time(self) -> int:
        """Epoch seconds for the start of the current UTC month."""
        now = datetime.now(timezone.utc)
        month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        return int(month_start.timestamp())

    def increment_calls(self, count: int = 1) -> None:
        """Bump usage counters and persist atomically via the owning store.

        The store performs a server-side increment (``calls_used = calls_used +
        delta``) so concurrent workers cannot lose updates. The in-memory view
        is advanced too so per-process rate-limit checks stay current.
        """
        self.last_used = time.time()
        store = self._store
        if store is not None:
            store.increment_calls(self.key_id, count, self.last_used)
        self.calls_used += count


_TIER_LIMITS = {
    "free": 0,
    "hobby": 5_000,
    "pro": 50_000,
    "team": 200_000,
    "enterprise": float("inf"),
}


class _HashBackend(Protocol):
    """Minimal protocol shared by SQLiteKeyStore and RedisKeyStore."""

    def create(
        self,
        key_id: str,
        key_hash: str,
        tier: str,
        calls_limit: int | float,
        key_fingerprint: str = "",
    ) -> None: ...

    def get_by_hash(self, key_hash: str) -> dict[str, Any] | None: ...

    def get_by_fingerprint(self, key_fingerprint: str) -> dict[str, Any] | None: ...

    def get_by_id(self, key_id: str) -> dict[str, Any] | None: ...

    def delete_by_hash(self, key_hash: str) -> bool: ...

    def update_calls(self, key_id: str, calls_used: int, last_used: float) -> None: ...

    def increment_calls(self, key_id: str, delta: int, last_used: float) -> None: ...


def _limit_for_backend(limit: int | float) -> int | float:
    """Map unlimited (inf) to 0 for backends that store numeric limits."""
    if limit == float("inf"):
        return 0
    return limit


def _limit_from_backend(limit: int | float) -> int | float:
    """0 means unlimited in store semantics (matches free / enterprise)."""
    if limit == 0:
        return 0
    return limit


class APIKeyStore:
    """API key store with pluggable persistence.

    Backends:

    * ``json`` (default) — hash-only JSON file (raw secret is never written;
      keyed by PBKDF2-HMAC-SHA256 of the secret). Writes are flock-serialized
      and ``os.replace``d atomically so a concurrent writer cannot truncate
      the file. Prefer ``sqlite`` for multi-worker / multi-replica.
    * ``sqlite`` — hash-only SQLite (WAL). Safe for multi-worker single host
      when the DB path is on a shared volume (e.g. ``/data/api_keys.db``).
    * ``redis`` — hash-only Redis. Safe for multi-replica (Cloud Run + Memorystore).

    Select via ``STORE_BACKEND`` (see :func:`get_key_store`).

    Legacy JSON files that used the raw secret as the object key are migrated
    on load: the secret is hashed with PBKDF2, the file is re-keyed by that
    hash, and the raw secret is dropped. Pre-v2 SHA-256 fingerprints without
    the raw secret cannot be verified and are skipped (re-issue those keys).

    New keys use a ``pyn_v2_`` prefix and store a SHA-256 fingerprint alongside
    the PBKDF2 verifier. Invalid ``pyn_v2_`` keys are rejected by one fast
    SHA-256 lookup instead of a 100k-iteration PBKDF2; legacy ``pyn_`` keys
    keep the PBKDF2-only fallback.
    """

    _DEFAULT_JSON_PATH = "/data/api_keys.json"

    def __init__(self, backend: _HashBackend | None = None, store_path: str | None = None) -> None:
        self._backend = backend
        # Read env at init time so tests can monkeypatch API_KEY_STORE.
        self._store_path = store_path or os.environ.get("API_KEY_STORE", self._DEFAULT_JSON_PATH)
        # JSON mode only — maps key_hash → APIKey (never raw secret).
        self._keys: dict[str, APIKey] = {}
        self._key_by_id: dict[str, str] = {}  # key_id → key_hash
        self._key_by_fingerprint: dict[str, str] = {}  # SHA-256(raw) → key_hash
        if self._backend is None:
            self._load()

    def _load(self) -> None:
        path = self._store_path
        if not os.path.exists(path):
            return
        migrated = False
        try:
            with open(path) as f:
                data = json.load(f)
            for store_key, info in data.items():
                if not isinstance(info, dict):
                    continue
                key_hash = str(info.get("key_hash") or "")
                key_id = str(info.get("key_id") or "")
                fingerprint = str(info.get("fingerprint") or "")
                if not key_hash or not key_id:
                    continue
                # Legacy format: object key was the raw secret (pyn_…). Rehash
                # with PBKDF2 now so lookup never uses SHA-256 on the secret.
                if store_key != key_hash:
                    key_hash = self._hash_key(store_key)
                    fingerprint = self._fingerprint_key(store_key)
                    migrated = True
                elif not key_hash.startswith("v2:"):
                    # SHA-256-keyed record; raw secret is gone. Skip.
                    migrated = True
                    continue
                api_key = APIKey(
                    key_id=key_id,
                    key_hash=key_hash,
                    key_fingerprint=fingerprint,
                    tier=info.get("tier", "free"),
                    calls_used=info.get("calls_used", 0),
                    calls_limit=info.get("calls_limit", 0),
                    created_at=info.get("created_at", 0.0),
                    last_used=info.get("last_used", 0.0),
                    _store=self,
                )
                self._keys[key_hash] = api_key
                self._key_by_id[key_id] = key_hash
                if fingerprint:
                    self._key_by_fingerprint[fingerprint] = key_hash
        except (OSError, json.JSONDecodeError, KeyError, TypeError, ValueError):
            # Corrupt or partial store — start empty rather than crash the API.
            self._keys.clear()
            self._key_by_id.clear()
            self._key_by_fingerprint.clear()
            return
        if migrated:
            # Persist hash-only layout so raw secrets never remain on disk.
            self._save()

    def _save(self) -> None:
        if self._backend is not None:
            return
        path = self._store_path
        parent = os.path.dirname(path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        data = {}
        for key_hash, api_key in self._keys.items():
            # Hash-only: object key is the PBKDF2 digest, never the raw secret.
            data[key_hash] = {
                "key_id": api_key.key_id,
                "key_hash": api_key.key_hash,
                "fingerprint": api_key.key_fingerprint,
                "tier": api_key.tier,
                "calls_used": api_key.calls_used,
                "calls_limit": api_key.calls_limit if api_key.calls_limit != float("inf") else 0,
                "created_at": api_key.created_at,
                "last_used": api_key.last_used,
            }
        lock_path = f"{path}.lock"
        tmp_dir = parent if parent else "."
        lock_fd = os.open(lock_path, os.O_CREAT | os.O_RDWR, 0o600)
        try:
            fcntl.flock(lock_fd, fcntl.LOCK_EX)
            tmp_fd, tmp_name = tempfile.mkstemp(prefix=".api_keys.", suffix=".tmp", dir=tmp_dir)
            replaced = False
            try:
                with os.fdopen(tmp_fd, "w", encoding="utf-8") as fh:
                    tmp_fd = -1
                    json.dump(data, fh, indent=2)
                os.replace(tmp_name, path)
                replaced = True
            finally:
                if tmp_fd >= 0:
                    try:
                        os.close(tmp_fd)
                    except OSError:
                        pass
                if not replaced:
                    try:
                        os.unlink(tmp_name)
                    except OSError:
                        pass
        finally:
            try:
                fcntl.flock(lock_fd, fcntl.LOCK_UN)
            except OSError:
                pass
            os.close(lock_fd)

    def persist_usage(self, api_key: APIKey) -> None:
        """Write call counters after :meth:`APIKey.increment_calls`."""
        if self._backend is not None:
            self._backend.update_calls(api_key.key_id, api_key.calls_used, api_key.last_used)
            return
        self._save()

    def increment_calls(self, key_id: str, delta: int, last_used: float) -> None:
        """Atomically increment *key_id*'s call counter by *delta*.

        JSON backend updates the in-memory record and rewrites the file
        (single-process by design). SQLite and Redis backends perform a
        server-side increment so concurrent workers never lose updates.
        """
        if self._backend is not None:
            self._backend.increment_calls(key_id, delta, last_used)
            return
        key_hash = self._key_by_id.get(key_id)
        if key_hash is None:
            return
        api_key = self._keys.get(key_hash)
        if api_key is None:
            return
        api_key.calls_used += delta
        api_key.last_used = last_used
        self._save()

    def create_key(self, tier: str = "hobby") -> tuple[str, str]:
        """Mint a new API key; returns ``(raw_key, key_id)`` (raw shown once)."""
        raw_key = f"pyn_v2_{secrets.token_urlsafe(32)}"
        key_id = secrets.token_hex(6)
        key_hash = self._hash_key(raw_key)
        key_fingerprint = self._fingerprint_key(raw_key)
        calls_limit = _TIER_LIMITS.get(tier, 0)

        if self._backend is not None:
            self._backend.create(
                key_id=key_id,
                key_hash=key_hash,
                key_fingerprint=key_fingerprint,
                tier=tier,
                calls_limit=_limit_for_backend(calls_limit),
            )
            return raw_key, key_id

        api_key = APIKey(
            key_id=key_id,
            key_hash=key_hash,
            key_fingerprint=key_fingerprint,
            tier=tier,
            calls_limit=calls_limit,
            _store=self,
        )
        self._keys[key_hash] = api_key
        self._key_by_id[key_id] = key_hash
        self._key_by_fingerprint[key_fingerprint] = key_hash
        self._save()
        return raw_key, key_id

    def _api_key_from_record(self, record: dict[str, Any]) -> APIKey:
        limit = _limit_from_backend(record.get("calls_limit", 0))
        return APIKey(
            key_id=record["key_id"],
            key_hash=record["key_hash"],
            key_fingerprint=str(record.get("key_fingerprint") or record.get("fingerprint") or ""),
            tier=record.get("tier", "free"),
            calls_used=int(record.get("calls_used", 0)),
            calls_limit=limit,
            created_at=float(record.get("created_at", 0.0)),
            last_used=float(record.get("last_used", 0.0)),
            _store=self,
        )

    def get_key(self, raw_key: str) -> APIKey | None:
        """Look up a key by raw secret.

        New ``pyn_v2_`` keys hit the SHA-256 fingerprint index first, so an
        invalid key costs one fast hash instead of a 100k-iteration PBKDF2.
        A fingerprint hit still verifies the PBKDF2 digest. Legacy ``pyn_``
        keys without a fingerprint fall back to the PBKDF2-only path.
        """
        if not raw_key or not raw_key.startswith("pyn_"):
            return None
        fingerprint = self._fingerprint_key(raw_key)
        is_v2 = raw_key.startswith("pyn_v2_")
        if self._backend is not None:
            record = self._backend.get_by_fingerprint(fingerprint)
            if record is not None:
                if not hmac.compare_digest(self._hash_key(raw_key), str(record.get("key_hash") or "")):
                    return None
                return self._api_key_from_record(record)
            if is_v2:
                return None
            record = self._backend.get_by_hash(self._hash_key(raw_key))
            if record is None:
                return None
            return self._api_key_from_record(record)

        key_hash = self._key_by_fingerprint.get(fingerprint)
        if key_hash is not None:
            api_key = self._keys.get(key_hash)
            if api_key is None or not hmac.compare_digest(self._hash_key(raw_key), api_key.key_hash):
                return None
            return api_key
        if is_v2:
            return None
        return self._keys.get(self._hash_key(raw_key))

    def get_by_id(self, key_id: str) -> APIKey | None:
        """Look up a key by public ``key_id`` (not the raw secret)."""
        if self._backend is not None:
            record = self._backend.get_by_id(key_id)
            if record is None:
                return None
            return self._api_key_from_record(record)
        key_hash = self._key_by_id.get(key_id)
        if key_hash:
            return self._keys.get(key_hash)
        return None

    def validate_key(self, raw_key: str) -> APIKey | None:
        """Return the key if present and active; else ``None``."""
        if not raw_key:
            return None
        api_key = self.get_key(raw_key)
        if api_key and api_key.is_active():
            return api_key
        return None

    def revoke_key(self, raw_key: str) -> bool:
        """Delete a key by raw secret; returns whether a record was removed."""
        if not raw_key or not raw_key.startswith("pyn_"):
            return False
        fingerprint = self._fingerprint_key(raw_key)
        is_v2 = raw_key.startswith("pyn_v2_")
        if self._backend is not None:
            record = self._backend.get_by_fingerprint(fingerprint)
            if record is not None:
                return self._backend.delete_by_hash(str(record.get("key_hash") or ""))
            if is_v2:
                return False
            return self._backend.delete_by_hash(self._hash_key(raw_key))

        key_hash = self._key_by_fingerprint.get(fingerprint)
        if key_hash is None:
            if is_v2:
                return False
            key_hash = self._hash_key(raw_key)
        api_key = self._keys.pop(key_hash, None)
        if api_key is None:
            return False
        self._key_by_id.pop(api_key.key_id, None)
        if api_key.key_fingerprint:
            self._key_by_fingerprint.pop(api_key.key_fingerprint, None)
        self._save()
        return True

    @staticmethod
    def _fingerprint_key(raw_key: str) -> str:
        """Fast SHA-256 fingerprint for the invalid-key fast path.

        This is not the stored verifier: a fingerprint hit still runs the
        PBKDF2 check. Keys are 256-bit random, so the fingerprint does not
        weaken a leaked store.
        """
        return hashlib.sha256(raw_key.encode("utf-8")).hexdigest()

    @staticmethod
    @functools.lru_cache(maxsize=1024)
    def _hash_key(raw_key: str) -> str:
        """Hash an API key for storage using PBKDF2-HMAC-SHA256 (v2).

        Cached: the salt is static so raw→hash is a pure function, and
        PBKDF2 at 100k iterations costs ~50-100ms per uncached call —
        which otherwise dominates every authenticated request latency.
        Raw keys are 256-bit random, so this does not weaken storage.
        """
        dk = hashlib.pbkdf2_hmac(
            "sha256",
            raw_key.encode(),
            _HASH_SALT,
            _HASH_ITERATIONS,
        )
        return f"v2:{dk.hex()}"


class _KeyStoreHolder:
    """Process-local holder so we avoid module-level ``global`` assignments."""

    store: APIKeyStore | None = None
    lock = threading.Lock()


def reset_key_store() -> None:
    """Drop the process-local singleton (tests / reconfiguration)."""
    _KeyStoreHolder.store = None


def _default_sqlite_path() -> str:
    # Prefer dedicated env; fall back next to JSON path with .db suffix.
    explicit = os.environ.get("API_KEY_STORE_SQLITE")
    if explicit:
        return explicit
    json_path = os.environ.get("API_KEY_STORE", "/data/api_keys.json")
    if json_path.endswith(".json"):
        return json_path[: -len(".json")] + ".db"
    return "/data/api_keys.db"


def _build_key_store() -> APIKeyStore:
    backend_name = (os.environ.get("STORE_BACKEND") or "json").strip().lower()
    if backend_name in {"sqlite", "sql", "db"}:
        from backend.middleware.key_store_sqlite import SQLiteKeyStore

        path = _default_sqlite_path()
        parent = os.path.dirname(path)
        if parent and path != ":memory:":
            os.makedirs(parent, exist_ok=True)
        return APIKeyStore(backend=SQLiteKeyStore(path))
    if backend_name in {"redis", "memorystore"}:
        from backend.middleware.key_store_redis import RedisKeyStore

        url = os.environ.get("REDIS_URL", "").strip()
        if not url:
            msg = "STORE_BACKEND=redis requires REDIS_URL to be set"
            raise RuntimeError(msg)
        return APIKeyStore(backend=RedisKeyStore(url=url))
    return APIKeyStore()


def get_key_store() -> APIKeyStore:
    """Return the process-local key store singleton.

    Backend selection (``STORE_BACKEND``, case-insensitive):

    * ``json`` (default) — hash-only file at ``API_KEY_STORE``
    * ``sqlite`` — ``API_KEY_STORE_SQLITE`` or ``API_KEY_STORE`` with ``.db``
    * ``redis`` — ``REDIS_URL`` (required)

    For multi-worker gunicorn use ``sqlite`` on a shared volume; for multi-replica
    Cloud Run use ``redis`` (e.g. Memorystore).
    """
    if _KeyStoreHolder.store is None:
        with _KeyStoreHolder.lock:
            if _KeyStoreHolder.store is None:
                _KeyStoreHolder.store = _build_key_store()
    return _KeyStoreHolder.store


def _env_truthy(name: str, default: str = "0") -> bool:
    raw = os.environ.get(name, default)
    return str(raw).strip().lower() not in {"0", "false", "no", "off", ""}


def _request_api_key() -> str:
    """Extract the API key from headers (query fallback is opt-in only)."""
    auth_header = request.headers.get("Authorization", "")
    if auth_header.startswith("Bearer "):
        return auth_header[7:]
    if auth_header.startswith("ApiKey "):
        return auth_header[7:]
    # Query-string keys leak through access logs, Referer and proxies. Keep the
    # legacy fallback behind an explicit env flag for old self-hosted clients.
    if _env_truthy("ALLOW_API_KEY_QUERY", "0"):
        return request.args.get("api_key", "")
    return ""


def require_api_key(f):
    """Decorator to require a valid API key for an endpoint."""

    @wraps(f)
    def decorated(*args, **kwargs):
        raw_key = _request_api_key()

        store = get_key_store()
        api_key = store.validate_key(raw_key)

        if api_key is None:
            return jsonify(
                {
                    "status": "error",
                    "code": "UNAUTHORIZED",
                    "message": "Invalid or missing API key. Get one at https://pynescript.ai",
                }
            ), 401

        if api_key.is_rate_limited():
            return jsonify(
                {
                    "status": "error",
                    "code": "RATE_LIMITED",
                    "message": f"Monthly limit reached ({api_key.calls_limit} calls). Upgrade at https://pynescript.ai",
                    "tier_info": api_key.get_tier_info(),
                }
            ), 429

        g.api_key = api_key
        return f(*args, **kwargs)

    return decorated


def optional_api_key(f):
    """Populate ``g.api_key`` when a valid key is supplied; never reject.

    Used by public data routes that may optionally consume owner-scoped
    credentials. Invalid/missing keys fall through as anonymous access.
    """

    @wraps(f)
    def decorated(*args, **kwargs):
        raw_key = _request_api_key()
        if raw_key:
            api_key = get_key_store().validate_key(raw_key)
            if api_key is not None and not api_key.is_rate_limited():
                g.api_key = api_key
        return f(*args, **kwargs)

    return decorated


def track_usage(f):
    """Decorator to track API call usage."""

    @wraps(f)
    @require_api_key
    def decorated(*args, **kwargs):
        api_key: APIKey = g.api_key
        result = f(*args, **kwargs)
        if isinstance(result, tuple):
            response, status_code = result
            if status_code < 400:  # HTTP success range
                api_key.increment_calls()
            return response, status_code
        api_key.increment_calls()
        return result

    return decorated


def _provided_admin_token() -> str:
    """Extract admin credential from request headers."""
    header = (request.headers.get("X-Admin-Token") or "").strip()
    if header:
        return header
    auth = (request.headers.get("Authorization") or "").strip()
    if auth.startswith("Bearer "):
        return auth[7:].strip()
    if auth.lower().startswith("admintoken "):
        return auth[11:].strip()
    return ""


def require_admin_token(f):
    """Require ``ADMIN_TOKEN`` via ``X-Admin-Token`` (or Bearer).

    Fail closed:

    * ``ADMIN_TOKEN`` unset/empty → 403 (admin minting disabled)
    * header missing or mismatch → 403

    Comparison uses :func:`hmac.compare_digest` (constant-time).
    """

    @wraps(f)
    def decorated(*args, **kwargs):
        expected = (os.environ.get("ADMIN_TOKEN") or "").strip()
        if not expected:
            return jsonify(
                {
                    "status": "error",
                    "code": "FORBIDDEN",
                    "message": "Admin access is disabled (ADMIN_TOKEN not configured).",
                }
            ), 403

        provided = _provided_admin_token()
        if not provided or not hmac.compare_digest(provided, expected):
            return jsonify(
                {
                    "status": "error",
                    "code": "FORBIDDEN",
                    "message": "Invalid or missing admin token (X-Admin-Token).",
                }
            ), 403

        g.is_admin = True
        return f(*args, **kwargs)

    return decorated
