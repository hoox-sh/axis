# Copyright (C) 2024-2026 jango_blockchained
#
# This file is part of pynescript.
#
# pynescript is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# pynescript is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with pynescript.  If not, see <https://www.gnu.org/licenses/>.
#
# SPDX-License-Identifier: AGPL-3.0-or-later

"""SQLite-backed API key store.

Used as the default persistent backend for ``APIKeyStore`` when running the
backend with more than one gunicorn worker. Schema:

    CREATE TABLE api_keys (
        key_hash TEXT PRIMARY KEY,        -- v2: PBKDF2-HMAC-SHA256 of the raw key
        key_fingerprint TEXT,             -- SHA-256(raw), invalid-key fast path
        key_id TEXT NOT NULL UNIQUE,
        tier TEXT NOT NULL,
        calls_used INTEGER NOT NULL DEFAULT 0,
        calls_limit INTEGER NOT NULL DEFAULT 0,
        created_at REAL NOT NULL,
        last_used REAL NOT NULL DEFAULT 0
    );

Thread-safety: ``sqlite3`` connections are guarded by a ``threading.Lock``.
WAL journal mode is enabled so multiple worker processes (each with their own
connection) can read concurrently while one writes.

We do not store the raw API key — only a ``v2:`` PBKDF2-HMAC-SHA256 digest
(100_000 iterations, static salt; ``APIKeyStore._hash_key``). A leaked DB
file exposes identifiers, tiers, and call counts, but not the keys themselves.
"""

from __future__ import annotations

import sqlite3
import threading
import time

from typing import Any


_SCHEMA = """
CREATE TABLE IF NOT EXISTS api_keys (
    key_hash        TEXT PRIMARY KEY,
    key_fingerprint TEXT,
    key_id          TEXT NOT NULL UNIQUE,
    tier            TEXT NOT NULL,
    calls_used      INTEGER NOT NULL DEFAULT 0,
    calls_limit     INTEGER NOT NULL DEFAULT 0,
    created_at      REAL NOT NULL,
    last_used       REAL NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_api_keys_key_id ON api_keys(key_id);
"""


class SQLiteKeyStore:
    """Thread-safe SQLite-backed key store.

    Args:
        path: SQLite file path, or ``":memory:"`` for an in-process DB (useful
            for tests). Defaults to a process-local file under
            ``$TMPDIR/pynescript_keys.db`` so dev runs share state.
    """

    def __init__(self, path: str = ":memory:") -> None:
        self._path = path
        # check_same_thread=False lets gunicorn worker threads share the
        # connection; the lock below serialises writes.
        self._conn = sqlite3.connect(self._path, check_same_thread=False, isolation_level=None)
        self._lock = threading.Lock()
        with self._lock:
            self._conn.executescript(_SCHEMA)
            # Additive migration for pre-fingerprint DBs.
            try:
                self._conn.execute("ALTER TABLE api_keys ADD COLUMN key_fingerprint TEXT")
            except sqlite3.OperationalError:
                pass
            self._conn.execute("CREATE INDEX IF NOT EXISTS idx_api_keys_fingerprint ON api_keys(key_fingerprint)")
            # WAL mode is a no-op for in-memory DBs; guard with the path.
            if self._path != ":memory:":
                try:
                    self._conn.execute("PRAGMA journal_mode=WAL")
                    self._conn.execute("PRAGMA synchronous=NORMAL")
                except sqlite3.DatabaseError:
                    # Some filesystems don't support WAL; fall back to default.
                    pass

    def create(
        self,
        key_id: str,
        key_hash: str,
        tier: str,
        calls_limit: int | float,
        key_fingerprint: str = "",
    ) -> None:
        """Insert a new hashed key row."""
        with self._lock:
            self._conn.execute(
                "INSERT INTO api_keys"
                " (key_hash, key_fingerprint, key_id, tier, calls_used, calls_limit, created_at, last_used)"
                " VALUES (?, ?, ?, ?, 0, ?, ?, 0)",
                (key_hash, key_fingerprint, key_id, tier, calls_limit, time.time()),
            )

    @staticmethod
    def _row_to_record(row: tuple[Any, ...]) -> dict[str, Any]:
        return {
            "key_id": row[0],
            "key_hash": row[1],
            "key_fingerprint": row[2] or "",
            "tier": row[3],
            "calls_used": row[4],
            "calls_limit": row[5],
            "created_at": row[6],
            "last_used": row[7],
        }

    def get_by_hash(self, key_hash: str) -> dict[str, Any] | None:
        """Return the key record for *key_hash*, or ``None``."""
        with self._lock:
            row = self._conn.execute(
                "SELECT key_id, key_hash, key_fingerprint, tier, calls_used, calls_limit, created_at, last_used"
                " FROM api_keys WHERE key_hash = ?",
                (key_hash,),
            ).fetchone()
        return None if row is None else self._row_to_record(row)

    def get_by_fingerprint(self, key_fingerprint: str) -> dict[str, Any] | None:
        """Return the key record for a SHA-256 fingerprint, or ``None``."""
        if not key_fingerprint:
            return None
        with self._lock:
            row = self._conn.execute(
                "SELECT key_id, key_hash, key_fingerprint, tier, calls_used, calls_limit, created_at, last_used"
                " FROM api_keys WHERE key_fingerprint = ?",
                (key_fingerprint,),
            ).fetchone()
        return None if row is None else self._row_to_record(row)

    def get_by_id(self, key_id: str) -> dict[str, Any] | None:
        """Return the key record for public *key_id*, or ``None``."""
        with self._lock:
            row = self._conn.execute(
                "SELECT key_id, key_hash, key_fingerprint, tier, calls_used, calls_limit, created_at, last_used"
                " FROM api_keys WHERE key_id = ?",
                (key_id,),
            ).fetchone()
        return None if row is None else self._row_to_record(row)

    def delete_by_hash(self, key_hash: str) -> bool:
        """Delete by hash; returns whether a row was removed."""
        with self._lock:
            cur = self._conn.execute("DELETE FROM api_keys WHERE key_hash = ?", (key_hash,))
            return cur.rowcount > 0

    def update_calls(self, key_id: str, calls_used: int, last_used: float) -> None:
        """Persist usage counters for *key_id* (absolute value; legacy path)."""
        with self._lock:
            self._conn.execute(
                "UPDATE api_keys SET calls_used = ?, last_used = ? WHERE key_id = ?",
                (calls_used, last_used, key_id),
            )

    def increment_calls(self, key_id: str, delta: int, last_used: float) -> None:
        """Atomically increment *key_id*'s call counter by *delta*.

        Uses ``calls_used = calls_used + ?`` so concurrent gunicorn workers
        never lose updates (read-modify-write race on the absolute form).
        """
        with self._lock:
            self._conn.execute(
                "UPDATE api_keys SET calls_used = calls_used + ?, last_used = ? WHERE key_id = ?",
                (delta, last_used, key_id),
            )

    def close(self) -> None:
        """Close the SQLite connection."""
        with self._lock:
            self._conn.close()
