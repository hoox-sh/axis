# Copyright (C) 2024-2026 jango_blockchained
#
# This file is part of pynescript.
#
# pynescript is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# pynescript is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with pynescript.  If not, see <https://www.gnu.org/licenses/>.
#
# SPDX-License-Identifier: AGPL-3.0-or-later

"""Pygments lexer for Pine Script (ANTLR4 token stream → Pygments tokens)."""

from __future__ import annotations

from typing import ClassVar

from antlr4 import InputStream
from antlr4 import Token as ANTLR4Token
from pygments.lexer import Lexer
from pygments.token import Token

from pynescript.ast.grammar.antlr4.lexer import PinescriptLexer as PinescriptANTLR4Lexer


class PinescriptLexer(Lexer):
    """Pygments :class:`~pygments.lexer.Lexer` backed by the ANTLR4 Pine lexer.

    Registered aliases include ``pinescript``; filenames match ``*.pine``.
    """

    name: ClassVar[str] = "Pinescript Lexer"

    aliases: ClassVar[list[str]] = ["pinescript"]
    filenames: ClassVar[list[str]] = ["*.pine"]

    url: ClassVar[str] = "https://www.tradingview.com/pine-script-docs/en/v5/Introduction.html"

    _token_type_mapping: ClassVar[dict] = {
        PinescriptANTLR4Lexer.AND: Token.Operator,
        PinescriptANTLR4Lexer.AS: Token.Keyword,
        PinescriptANTLR4Lexer.BREAK: Token.Keyword,
        PinescriptANTLR4Lexer.BY: Token.Keyword,
        PinescriptANTLR4Lexer.CONST: Token.Keyword,
        PinescriptANTLR4Lexer.CONTINUE: Token.Keyword,
        PinescriptANTLR4Lexer.ELSE: Token.Keyword,
        PinescriptANTLR4Lexer.EXPORT: Token.Keyword,
        PinescriptANTLR4Lexer.FALSE: Token.Literal,
        PinescriptANTLR4Lexer.FOR: Token.Keyword,
        PinescriptANTLR4Lexer.IF: Token.Keyword,
        PinescriptANTLR4Lexer.IMPORT: Token.Keyword,
        PinescriptANTLR4Lexer.IN: Token.Keyword,
        PinescriptANTLR4Lexer.INPUT: Token.Keyword,
        PinescriptANTLR4Lexer.METHOD: Token.Keyword,
        PinescriptANTLR4Lexer.NOT: Token.Operator,
        PinescriptANTLR4Lexer.OR: Token.Operator,
        PinescriptANTLR4Lexer.SERIES: Token.Keyword,
        PinescriptANTLR4Lexer.SIMPLE: Token.Keyword,
        PinescriptANTLR4Lexer.SWITCH: Token.Keyword,
        PinescriptANTLR4Lexer.TO: Token.Keyword,
        PinescriptANTLR4Lexer.TYPE: Token.Keyword,
        PinescriptANTLR4Lexer.TRUE: Token.Literal,
        PinescriptANTLR4Lexer.VAR: Token.Keyword,
        PinescriptANTLR4Lexer.VARIP: Token.Keyword,
        PinescriptANTLR4Lexer.WHILE: Token.Keyword,
        PinescriptANTLR4Lexer.WS: Token.Text.Whitespace,
        PinescriptANTLR4Lexer.COMMENT: Token.Comment,
        PinescriptANTLR4Lexer.LPAR: Token.Punctuation,
        PinescriptANTLR4Lexer.RPAR: Token.Punctuation,
        PinescriptANTLR4Lexer.LSQB: Token.Punctuation,
        PinescriptANTLR4Lexer.RSQB: Token.Punctuation,
        PinescriptANTLR4Lexer.LESS: Token.Operator,
        PinescriptANTLR4Lexer.GREATER: Token.Operator,
        PinescriptANTLR4Lexer.EQUAL: Token.Operator,
        PinescriptANTLR4Lexer.EQEQUAL: Token.Operator,
        PinescriptANTLR4Lexer.NOTEQUAL: Token.Operator,
        PinescriptANTLR4Lexer.LESSEQUAL: Token.Operator,
        PinescriptANTLR4Lexer.GREATEREQUAL: Token.Operator,
        PinescriptANTLR4Lexer.RARROW: Token.Punctuation,
        PinescriptANTLR4Lexer.DOT: Token.Punctuation,
        PinescriptANTLR4Lexer.COMMA: Token.Punctuation,
        PinescriptANTLR4Lexer.COLON: Token.Operator,
        PinescriptANTLR4Lexer.QUESTION: Token.Operator,
        PinescriptANTLR4Lexer.PLUS: Token.Operator,
        PinescriptANTLR4Lexer.MINUS: Token.Operator,
        PinescriptANTLR4Lexer.STAR: Token.Operator,
        PinescriptANTLR4Lexer.SLASH: Token.Operator,
        PinescriptANTLR4Lexer.PERCENT: Token.Operator,
        PinescriptANTLR4Lexer.PLUSEQUAL: Token.Operator,
        PinescriptANTLR4Lexer.MINEQUAL: Token.Operator,
        PinescriptANTLR4Lexer.STAREQUAL: Token.Operator,
        PinescriptANTLR4Lexer.SLASHEQUAL: Token.Operator,
        PinescriptANTLR4Lexer.PERCENTEQUAL: Token.Operator,
        PinescriptANTLR4Lexer.COLONEQUAL: Token.Operator,
        PinescriptANTLR4Lexer.NAME: Token.Name,
        PinescriptANTLR4Lexer.NUMBER: Token.Literal.Number,
        PinescriptANTLR4Lexer.STRING: Token.Literal.String,
        PinescriptANTLR4Lexer.COLOR: Token.Literal,
        PinescriptANTLR4Lexer.NEWLINE: Token.Text.Whitespace,
        PinescriptANTLR4Lexer.WS: Token.Text.Whitespace,
        PinescriptANTLR4Lexer.COMMENT: Token.Comment,
        PinescriptANTLR4Lexer.ERROR_TOKEN: Token.Error,
    }

    def get_tokens_unprocessed(self, text: str):
        """Yield ``(index, tokentype, value)`` for Pygments highlighting."""
        stream = InputStream(text)
        lexer = PinescriptANTLR4Lexer(stream)
        while True:
            token = lexer.nextToken()
            if token is None:
                return
            if token.type in {ANTLR4Token.EOF}:
                return
            if token.type in {PinescriptANTLR4Lexer.INDENT, PinescriptANTLR4Lexer.DEDENT}:
                continue
            yield token.start, self._token_type_mapping.get(token.type, Token.Other), token.text
