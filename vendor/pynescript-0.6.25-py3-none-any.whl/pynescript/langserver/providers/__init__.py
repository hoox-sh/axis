# Copyright (C) 2024-2026 jango_blockchained
#
# This file is part of pynescript.
#
# pynescript is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# pynescript is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with pynescript.  If not, see <https://www.gnu.org/licenses/>.
#
# SPDX-License-Identifier: AGPL-3.0-or-later

"""Builtin metadata and completion-item builders for the language server.

Modules:

- :mod:`.builtin_metadata` — load/cache Pine Script builtin docs (JSON / encrypted)
- :mod:`.completion_items` — build :class:`~lsprotocol.types.CompletionItem` lists
- :mod:`.metadata_decrypt` — Fernet decrypt of ``builtin_metadata.json.enc``

Feature handlers (completion, hover, inlay types) import these modules by name;
this package does not re-export.
"""

from __future__ import annotations
