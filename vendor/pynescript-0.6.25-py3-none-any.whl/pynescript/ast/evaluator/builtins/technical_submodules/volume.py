# Copyright (C) 2024-2026 jango_blockchained
#
# This file is part of pynescript.
#
# pynescript is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# pynescript is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with pynescript.  If not, see <https://www.gnu.org/licenses/>.
#
# SPDX-License-Identifier: AGPL-3.0-or-later

"""Volume-based ``ta.*`` indicators (OBV, MFI, CMF, WAD, WVAD, …).

Handlers are composed into
:class:`~pynescript.ast.evaluator.builtins.technical.TechnicalAnalysisMixin`.
"""

from __future__ import annotations

import math

from collections import deque
from typing import Any

from .core import BINARY
from .core import QUATERNARY
from .core import QUINARY
from .core import TERNARY
from .core import UNARY
from .core import TechnicalHelpers


def _last_finite(ev: TechnicalHelpers, x: Any) -> float | None:
    """Current-bar numeric sample, or ``None`` for missing / non-numeric / NaN."""
    x = ev._series_last(x)
    if x is None:
        return None
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    if v != v:
        return None
    return v


class VolumeIndicators(TechnicalHelpers):
    """Volume ``ta.*``: OBV, MFI, CMF, WAD/WVAD, and related volume flow series."""

    # -- Public API (builtin_ta_ prefix) ------------------------------------

    def _builtin_ta_obv(self, args: list[Any]) -> Any:
        """On-Balance Volume.

        Forms:
        - ``ta.obv`` / ``ta.obv()`` — chart close + volume
        - ``ta.obv(close, volume)`` — explicit series
        """
        msg = "ta.obv expects close and volume series (or no args)"
        if self._use_incremental_ta():
            if len(args) == 0:
                closes = self._context_source("close")
                volumes = self._context_source("volume")
                if not volumes:
                    volumes = 0.0
            elif len(args) == BINARY:
                closes = self._as_series_or_raw(args[0], last_sample_ok=True)
                volumes = self._as_series_or_raw(args[1], last_sample_ok=True)
            else:
                self._error(msg)
                return None
            return self._obv_inc_update(closes, volumes)
        if len(args) == 0:
            closes = self._context_series("close")
            volumes = self._context_series("volume")
            if not volumes:
                volumes = [0.0] * len(closes)
        elif len(args) == BINARY:
            closes = self._expect_list(args[0], msg)
            volumes = self._expect_list(args[1], msg)
        else:
            self._error(msg)
            return None
        if not closes:
            return None
        n = min(len(closes), len(volumes)) if volumes else 0
        if n == 0:
            return None
        # _obv returns the current cumulative scalar (bar-mode friendly)
        return self._obv(closes[-n:], volumes[-n:])

    def _builtin_ta_mfi(self, args: list[Any]) -> float | None:
        """Money Flow Index.

        Forms:
        - ``ta.mfi(length)`` / bare ``mfi(length)`` — hlc3 + volume from context
        - ``ta.mfi(source, length)`` — source as typical price + context volume
        - legacy 5-arg HLC+volume+length
        """
        use_inc = self._use_incremental_ta()
        if len(args) == UNARY and self._is_period_like(args[0]):
            length = self._expect_int(args[0], "ta.mfi length must be int")
            if use_inc:
                highs = self._context_source("high")
                lows = self._context_source("low")
                closes = self._context_source("close")
                volumes = self._context_source("volume")
                if not volumes:
                    volumes = [0.0]
                return self._mfi_inc_update(highs, lows, closes, volumes, length)
            highs = self._context_series("high")
            lows = self._context_series("low")
            closes = self._context_series("close")
            volumes = self._context_series("volume") or [0.0] * len(closes)
            n = min(len(highs), len(lows), len(closes), len(volumes))
            if n == 0:
                return None
            return self._mfi(highs[-n:], lows[-n:], closes[-n:], volumes[-n:], length)
        if len(args) == BINARY:
            length = self._expect_int(args[1], "ta.mfi length must be int")
            if use_inc:
                series = self._as_series_or_raw(args[0], last_sample_ok=True)
                volumes = self._context_source("volume")
                if not volumes:
                    volumes = [0.0]
                return self._mfi_inc_update(series, series, series, volumes, length)
            series = self._as_series(args[0])
            volumes = self._context_series("volume")
            if not volumes:
                volumes = [0.0] * len(series)
            n = min(len(series), len(volumes))
            if n == 0:
                return None
            series = series[-n:]
            volumes = volumes[-n:]
            return self._mfi(series, series, series, volumes, length)
        msg = "ta.mfi expects source, length (or high, low, close, volume, length)"
        self._require_len(args, QUINARY, msg)
        length = self._expect_int(args[4], msg)
        if use_inc:
            return self._mfi_inc_update(args[0], args[1], args[2], args[3], length)
        highs = self._expect_list(args[0], msg)
        lows = self._expect_list(args[1], msg)
        closes = self._expect_list(args[2], msg)
        volumes = self._expect_list(args[3], msg)
        return self._mfi(highs, lows, closes, volumes, length)

    def _builtin_ta_accdist(self, args: list[Any]) -> Any:
        """Accumulation/Distribution Index.

        Reference Pine: ``ta.accdist`` / ``ta.accdist()`` with no args uses H/L/C/V context.
        """
        if len(args) == 0:
            if self._use_incremental_ta():
                return self._accdist_inc_update(
                    self._context_source("high"),
                    self._context_source("low"),
                    self._context_source("close"),
                    self._context_source("volume"),
                )
            high_series = self._context_series("high")
            low_series = self._context_series("low")
            close_series = self._context_series("close")
            volume_series = self._context_series("volume")
        elif len(args) >= QUATERNARY:
            if self._use_incremental_ta():
                return self._accdist_inc_update(args[0], args[1], args[2], args[3])
            high_series = self._as_series(args[0])
            low_series = self._as_series(args[1])
            close_series = self._as_series(args[2])
            volume_series = self._as_series(args[3])
        else:
            self._error("ta.accdist() requires 0 or 4 arguments: high, low, close, volume")
            return None

        return self._finalize_series(self._accdist(high_series, low_series, close_series, volume_series))

    def _accdist_inc_update(
        self,
        high: Any,
        low: Any,
        close: Any,
        volume: Any,
    ) -> float | None:
        """Incremental cumulative A/D — safe under ``_SERIES_MAX`` list caps.

        Full recompute from capped ``current_series`` restarts the sum each bar
        after the cap window slides, diverging from compile ``numba_accdist_inc``.
        """
        slot = self._ta_next_slot()
        key = ("accdist", slot)
        bucket = self._ta_state_bucket()
        st = bucket.get(key)
        if st is None:
            st = {"ad": 0.0}
            bucket[key] = st

        def _f(x: Any) -> float | None:
            x = self._series_last(x)
            if x is None:
                return None
            try:
                v = float(x)
            except (TypeError, ValueError):
                return None
            if v != v:
                return None
            return v

        h, l_, c, vol = _f(high), _f(low), _f(close), _f(volume)
        if h is None or l_ is None or c is None:
            return st.get("ad")
        vv = 0.0 if vol is None else vol
        rng = h - l_
        if rng == 0.0:
            clv = 0.0
        else:
            clv = ((c - l_) - (h - c)) / rng
        st["ad"] = float(st["ad"]) + clv * vv
        return st["ad"]

    def _obv_inc_update(self, closes: Any, volumes: Any) -> float:
        """Incremental On-Balance Volume matching full ``_obv`` last value.

        Full path returns ``0`` until 3 samples, then accumulates from index 2
        (skips ``close[0]`` vs ``close[1]``). Safe under ``_SERIES_MAX`` caps.
        """
        slot = self._ta_next_slot()
        key = ("obv", slot)
        bucket = self._ta_state_bucket()
        st = bucket.get(key)
        if st is None:
            st = {"obv": 0.0, "prev": None, "bars": 0}
            bucket[key] = st

        cf = _last_finite(self, closes)
        vf = _last_finite(self, volumes)
        bars = int(st["bars"]) + 1
        st["bars"] = bars

        if bars < 3:
            st["prev"] = cf
            st["obv"] = 0.0
            return 0.0

        prev = st["prev"]
        if cf is not None and prev is not None and vf is not None:
            if cf > prev:
                st["obv"] = float(st["obv"]) + vf
            elif cf < prev:
                st["obv"] = float(st["obv"]) - vf
        if cf is not None:
            st["prev"] = cf
        return float(st["obv"])

    def _wad_inc_update(
        self,
        high: Any,
        low: Any,
        close: Any,
        volume: Any,
    ) -> float:
        """Incremental Williams A/D matching full ``_wad`` last value.

        First bar is ``0.0``. Later bars add ``vol*(close-low)`` on up closes
        and subtract ``vol*(high-close)`` on down closes.
        """
        slot = self._ta_next_slot()
        key = ("wad", slot)
        bucket = self._ta_state_bucket()
        st = bucket.get(key)
        if st is None:
            st = {"wad": 0.0, "prev": None, "started": False}
            bucket[key] = st

        h = _last_finite(self, high)
        l_ = _last_finite(self, low)
        c = _last_finite(self, close)
        v = _last_finite(self, volume)
        vv = 0.0 if v is None else v

        if not st["started"]:
            st["started"] = True
            st["prev"] = c
            st["wad"] = 0.0
            return 0.0

        prev = st["prev"]
        if c is not None and prev is not None:
            hi = h if h is not None else c
            lo = l_ if l_ is not None else c
            if c > prev:
                st["wad"] = float(st["wad"]) + vv * (c - lo)
            elif c < prev:
                st["wad"] = float(st["wad"]) - vv * (hi - c)
        if c is not None:
            st["prev"] = c
        return float(st["wad"])

    def _wvad_inc_update(
        self,
        high: Any,
        low: Any,
        close: Any,
        volume: Any,
        period: int,
    ) -> float:
        """Incremental Williams Volume A/D: last WAD / rolling volume sum."""
        wad = self._wad_inc_update(high, low, close, volume)
        if period <= 0:
            slot = self._ta_next_slot()
            key = ("wvad", slot, 0)
            bucket = self._ta_state_bucket()
            bucket.setdefault(key, {"value": 0.0})
            return 0.0
        slot = self._ta_next_slot()
        key = ("wvad", slot, int(period))
        bucket = self._ta_state_bucket()
        st = bucket.get(key)
        if st is None:
            st = {"vols": deque(maxlen=period), "vol_sum": 0.0}
            bucket[key] = st

        v = _last_finite(self, volume)
        vv = 0.0 if v is None else v
        vols: deque[float] = st["vols"]
        if len(vols) == period:
            st["vol_sum"] = float(st["vol_sum"]) - float(vols[0])
        vols.append(vv)
        st["vol_sum"] = float(st["vol_sum"]) + vv
        vol_sum = float(st["vol_sum"])
        if vol_sum > 0.0 and wad is not None:
            return float(wad) / vol_sum
        return 0.0

    def _cmf_inc_update(
        self,
        close: Any,
        high: Any,
        low: Any,
        volume: Any,
        period: int,
    ) -> float | None:
        """Incremental Chaikin Money Flow matching full ``_cmf`` last value.

        Partial windows are allowed (same as the full rebuild).
        """
        if period <= 0:
            slot = self._ta_next_slot()
            key = ("cmf", slot, 0)
            self._ta_state_bucket().setdefault(key, {"value": None})
            return None
        slot = self._ta_next_slot()
        key = ("cmf", slot, int(period))
        bucket = self._ta_state_bucket()
        st = bucket.get(key)
        if st is None:
            st = {
                "mf": deque(maxlen=period),
                "vol": deque(maxlen=period),
                "mf_sum": 0.0,
                "vol_sum": 0.0,
                "value": None,
            }
            bucket[key] = st

        h = _last_finite(self, high)
        l_ = _last_finite(self, low)
        c = _last_finite(self, close)
        v = _last_finite(self, volume)
        vv = 0.0 if v is None else v
        if h is None or l_ is None or c is None:
            clv = 0.0
        else:
            rng = h - l_
            clv = 0.0 if rng == 0.0 else ((c - l_) - (h - c)) / rng
        mf = clv * vv

        mfs: deque[float] = st["mf"]
        vols: deque[float] = st["vol"]
        if len(mfs) == period:
            st["mf_sum"] = float(st["mf_sum"]) - float(mfs[0])
            st["vol_sum"] = float(st["vol_sum"]) - float(vols[0])
        mfs.append(mf)
        vols.append(vv)
        st["mf_sum"] = float(st["mf_sum"]) + mf
        st["vol_sum"] = float(st["vol_sum"]) + vv
        vol_sum = float(st["vol_sum"])
        if vol_sum > 0.0:
            st["value"] = float(st["mf_sum"]) / vol_sum
        else:
            st["value"] = 0.0
        return st["value"]

    def _klinger_inc_update(
        self,
        close: Any,
        volume: Any,
        fast_period: int,
        slow_period: int,
    ) -> float | None:
        """Incremental Klinger: signed volume cumulant + two EMA call sites.

        Matches last value of full ``_klinger`` (TRV → cumsum → EMA fast/slow).
        """
        slot = self._ta_next_slot()
        key = ("klinger", slot)
        bucket = self._ta_state_bucket()
        st = bucket.get(key)
        if st is None:
            st = {"prev": None, "cum": 0.0, "started": False}
            bucket[key] = st

        c = _last_finite(self, close)
        v = _last_finite(self, volume)
        vv = 0.0 if v is None else v

        if not st["started"]:
            st["started"] = True
            st["prev"] = c
            st["cum"] = 0.0
        else:
            prev = st["prev"]
            if c is not None and prev is not None:
                if c > prev:
                    trv = vv
                elif c < prev:
                    trv = -vv
                else:
                    trv = 0.0
            else:
                trv = 0.0
            st["cum"] = float(st["cum"]) + trv
            if c is not None:
                st["prev"] = c

        cum = float(st["cum"])
        # Nested EMA call sites must run every bar (slot order).
        fast_v = self._ema_inc_update(cum, fast_period)
        slow_v = self._ema_inc_update(cum, slow_period)
        if fast_v is None or slow_v is None:
            return None
        try:
            return float(fast_v) - float(slow_v)
        except (TypeError, ValueError):
            return None

    def _nvi_inc_update(self, closes: Any, volumes: Any) -> float:
        """Incremental Negative Volume Index matching full ``ta.nvi`` last value.

        Seed ``1000.0`` on the first bar. Later bars multiply by
        ``(1 + close_change)`` when volume decreases. Missing / non-numeric
        close skips the increment (not coerced to 0). Empty volume contributes 0.
        """
        slot = self._ta_next_slot()
        key = ("nvi", slot)
        bucket = self._ta_state_bucket()
        st = bucket.get(key)
        if st is None:
            st = {"nvi": 1000.0, "prev_c": None, "prev_v": None, "started": False}
            bucket[key] = st

        cf = _last_finite(self, closes)
        vf = _last_finite(self, volumes)
        vv = 0.0 if vf is None else vf

        if not st["started"]:
            st["started"] = True
            st["prev_c"] = cf
            st["prev_v"] = vv
            st["nvi"] = 1000.0
            return 1000.0

        prev_c = st["prev_c"]
        prev_v = st["prev_v"]
        if cf is not None and prev_c is not None:
            if prev_c != 0.0:
                close_change = (cf - prev_c) / prev_c
            else:
                close_change = 0.0
            pv = 0.0 if prev_v is None else float(prev_v)
            if vv < pv:
                st["nvi"] = float(st["nvi"]) * (1.0 + close_change)
        if cf is not None:
            st["prev_c"] = cf
        st["prev_v"] = vv
        return float(st["nvi"])

    def _pvi_inc_update(self, closes: Any, volumes: Any) -> float:
        """Incremental Positive Volume Index matching full ``ta.pvi`` last value.

        Seed ``1000.0`` on the first bar. Later bars multiply by
        ``(1 + close_change)`` when volume increases. Missing / non-numeric
        close skips the increment (not coerced to 0). Empty volume contributes 0.
        """
        slot = self._ta_next_slot()
        key = ("pvi", slot)
        bucket = self._ta_state_bucket()
        st = bucket.get(key)
        if st is None:
            st = {"pvi": 1000.0, "prev_c": None, "prev_v": None, "started": False}
            bucket[key] = st

        cf = _last_finite(self, closes)
        vf = _last_finite(self, volumes)
        vv = 0.0 if vf is None else vf

        if not st["started"]:
            st["started"] = True
            st["prev_c"] = cf
            st["prev_v"] = vv
            st["pvi"] = 1000.0
            return 1000.0

        prev_c = st["prev_c"]
        prev_v = st["prev_v"]
        if cf is not None and prev_c is not None:
            if prev_c != 0.0:
                close_change = (cf - prev_c) / prev_c
            else:
                close_change = 0.0
            pv = 0.0 if prev_v is None else float(prev_v)
            if vv > pv:
                st["pvi"] = float(st["pvi"]) * (1.0 + close_change)
        if cf is not None:
            st["prev_c"] = cf
        st["prev_v"] = vv
        return float(st["pvi"])

    def _builtin_ta_wad(self, args: list[Any]) -> Any:
        """Williams Accumulation/Distribution - volume accumulation index.

        Forms:
        - ``ta.wad`` / ``ta.wad()`` — chart high/low/close/volume
        - ``ta.wad(high, low, close, volume)`` — explicit series
        """
        if self._use_incremental_ta():
            if len(args) == 0:
                return self._wad_inc_update(
                    self._context_source("high"),
                    self._context_source("low"),
                    self._context_source("close"),
                    self._context_source("volume") or 0.0,
                )
            if len(args) >= QUATERNARY:
                return self._wad_inc_update(
                    self._as_series_or_raw(args[0], last_sample_ok=True),
                    self._as_series_or_raw(args[1], last_sample_ok=True),
                    self._as_series_or_raw(args[2], last_sample_ok=True),
                    self._as_series_or_raw(args[3], last_sample_ok=True),
                )
            self._error("ta.wad() requires 0 or 4 arguments: high, low, close, volume")
            return None
        if len(args) == 0:
            high_series = self._context_series("high")
            low_series = self._context_series("low")
            close_series = self._context_series("close")
            volume_series = self._context_series("volume") or [0.0] * len(close_series)
        elif len(args) >= QUATERNARY:
            high_series = self._as_series(args[0])
            low_series = self._as_series(args[1])
            close_series = self._as_series(args[2])
            volume_series = self._as_series(args[3])
        else:
            self._error("ta.wad() requires 0 or 4 arguments: high, low, close, volume")
            return []

        return self._wad(high_series, low_series, close_series, volume_series)

    def _builtin_ta_wvad(self, args: list[Any]) -> Any:
        """Williams Volume Accumulation/Distribution - normalized WAD.

        Forms:
        - ``ta.wvad(period)`` — H/L/C/V from context
        - ``ta.wvad(high, low, close, volume, period?)``
        """
        if self._use_incremental_ta():
            if len(args) == UNARY and self._is_period_like(args[0]):
                period = self._expect_int(args[0], "period must be integer")
                return self._wvad_inc_update(
                    self._context_source("high"),
                    self._context_source("low"),
                    self._context_source("close"),
                    self._context_source("volume") or 0.0,
                    period,
                )
            if len(args) == 0:
                return self._wvad_inc_update(
                    self._context_source("high"),
                    self._context_source("low"),
                    self._context_source("close"),
                    self._context_source("volume") or 0.0,
                    20,
                )
            if len(args) < QUATERNARY:
                self._error("ta.wvad() requires 0, 1, or 4+ arguments: [high, low, close, volume,] period")
                return None
            period = self._expect_int(args[QUATERNARY], "period must be integer") if len(args) > QUATERNARY else 20
            return self._wvad_inc_update(
                self._as_series_or_raw(args[0], last_sample_ok=True),
                self._as_series_or_raw(args[1], last_sample_ok=True),
                self._as_series_or_raw(args[2], last_sample_ok=True),
                self._as_series_or_raw(args[3], last_sample_ok=True),
                period,
            )
        if len(args) == UNARY and self._is_period_like(args[0]):
            period = self._expect_int(args[0], "period must be integer")
            high_series = self._context_series("high")
            low_series = self._context_series("low")
            close_series = self._context_series("close")
            volume_series = self._context_series("volume") or [0.0] * len(close_series)
            return self._wvad(high_series, low_series, close_series, volume_series, period)
        if len(args) == 0:
            high_series = self._context_series("high")
            low_series = self._context_series("low")
            close_series = self._context_series("close")
            volume_series = self._context_series("volume") or [0.0] * len(close_series)
            return self._wvad(high_series, low_series, close_series, volume_series, 20)
        if len(args) < QUATERNARY:
            self._error("ta.wvad() requires 0, 1, or 4+ arguments: [high, low, close, volume,] period")
            return []

        high_series = self._as_series(args[0])
        low_series = self._as_series(args[1])
        close_series = self._as_series(args[2])
        volume_series = self._as_series(args[3])
        period_arg_idx = QUATERNARY
        default_period = 20
        period = (
            self._expect_int(args[period_arg_idx], "period must be integer")
            if len(args) > period_arg_idx
            else default_period
        )

        return self._wvad(high_series, low_series, close_series, volume_series, period)

    def _builtin_ta_cmf(self, args: list[Any]) -> Any:
        """Chaikin Money Flow indicator.

        Forms:
        - ``ta.cmf(period)`` — H/L/C/V from chart context
        - ``ta.cmf(close, high, low, volume, period)`` — explicit series
        """
        if self._use_incremental_ta():
            if len(args) == UNARY and self._is_period_like(args[0]):
                period = self._expect_int(args[0], "ta.cmf period must be integer")
                return self._cmf_inc_update(
                    self._context_source("close"),
                    self._context_source("high"),
                    self._context_source("low"),
                    self._context_source("volume") or 0.0,
                    period,
                )
            if len(args) < QUINARY:
                self._error("ta.cmf() requires 1 argument (period) or 5: close, high, low, volume, period")
                return None
            period = self._expect_int(args[4], "ta.cmf period must be integer")
            return self._cmf_inc_update(
                self._as_series_or_raw(args[0], last_sample_ok=True),
                self._as_series_or_raw(args[1], last_sample_ok=True),
                self._as_series_or_raw(args[2], last_sample_ok=True),
                self._as_series_or_raw(args[3], last_sample_ok=True),
                period,
            )
        if len(args) == UNARY and self._is_period_like(args[0]):
            period = self._expect_int(args[0], "ta.cmf period must be integer")
            high_series = self._context_series("high")
            low_series = self._context_series("low")
            close_series = self._context_series("close")
            volume_series = self._context_series("volume") or [0.0] * len(close_series)
            return self._cmf(close_series, high_series, low_series, volume_series, period)
        if len(args) < QUINARY:
            self._error("ta.cmf() requires 1 argument (period) or 5: close, high, low, volume, period")
            return []

        close_series = self._as_series(args[0])
        high_series = self._as_series(args[1])
        low_series = self._as_series(args[2])
        volume_series = self._as_series(args[3])
        period = self._expect_int(args[4], "ta.cmf period must be integer")

        return self._cmf(close_series, high_series, low_series, volume_series, period)

    def _builtin_ta_klinger(self, args: list[Any]) -> Any:
        """Klinger Oscillator.

        ta.klinger(high, low, close, volume, fast_period, slow_period)
        Volume-based momentum oscillator.
        Returns KO series (full) or last scalar (incremental bar mode).
        """
        senary = 6
        if len(args) < senary:
            msg = "ta.klinger() requires 6 arguments: high, low, close, volume, fast_period, slow_period"
            self._error(msg)

        fast_period = self._expect_int(args[4], "ta.klinger fast_period must be integer")
        slow_period = self._expect_int(args[5], "ta.klinger slow_period must be integer")
        if self._use_incremental_ta():
            return self._klinger_inc_update(
                self._as_series_or_raw(args[2], last_sample_ok=True),
                self._as_series_or_raw(args[3], last_sample_ok=True),
                fast_period,
                slow_period,
            )

        close_series = args[2] if isinstance(args[2], list) else [args[2]]
        volume_series = args[3] if isinstance(args[3], list) else [args[3]]
        return self._klinger(close_series, volume_series, fast_period, slow_period)

    def _builtin_ta_apo(self, args: list[Any]) -> Any:
        """Absolute Price Oscillator.

        ta.apo(series, fast_period, slow_period)
        APO = EMA(fast) - EMA(slow)
        Returns APO series (full) or last scalar (incremental bar mode).
        """
        if len(args) < TERNARY:
            msg = "ta.apo() requires 3 arguments: series, fast_period, slow_period"
            self._error(msg)

        fast = self._expect_int(args[1], "ta.apo fast_period must be integer")
        slow = self._expect_int(args[2], "ta.apo slow_period must be integer")
        if self._use_incremental_ta():
            return self._apo_inc_update(
                self._as_series_or_raw(args[0], last_sample_ok=True),
                fast,
                slow,
            )

        series = self._as_series(args[0])
        return self._finalize_series(self._apo(series, fast, slow))

    def _builtin_ta_vpt(self, args: list[Any]) -> float | None:
        """Volume Price Trend / Price Volume Trend.

        Forms:
        - ``ta.vpt`` / ``ta.pvt`` / ``ta.vpt()`` — chart close + volume
        - ``ta.vpt(series)`` — unused series arg for API compatibility (chart OHLCV used)
        """
        if self._use_incremental_ta():
            closes = self._context_source("close")
            volumes = self._context_source("volume")
            if not volumes:
                volumes = 0.0
            return self._vpt_inc_update(closes, volumes)
        closes = self._context_series("close")
        volumes = self._context_series("volume")
        if not volumes and closes:
            volumes = [0.0] * len(closes)
        if not closes or not volumes:
            # Fallback: host may only populate current_series
            cs = getattr(self, "current_series", None) or {}
            closes = cs.get("close", closes) or []
            volumes = cs.get("volume", volumes) or []
        if not closes or not volumes:
            return None
        return self._vpt(closes, volumes)

    def _vpt_inc_update(self, closes: Any, volumes: Any) -> float:
        """Incremental cumulative VPT matching compile ``numba_pvt_inc``.

        Bar 0 is ``0.0``. Later bars add ``vol * (close - prev) / prev``.
        """
        slot = self._ta_next_slot()
        key = ("vpt", slot)
        bucket = self._ta_state_bucket()
        st = bucket.get(key)
        if st is None:
            st = {"vpt": 0.0, "prev_c": None, "started": False}
            bucket[key] = st

        cf = _last_finite(self, closes)
        vf = _last_finite(self, volumes)
        vv = 0.0 if vf is None else vf

        if not st["started"]:
            st["started"] = True
            st["prev_c"] = cf
            st["vpt"] = 0.0
            return 0.0

        prev_c = st["prev_c"]
        if cf is not None and prev_c is not None and prev_c != 0.0:
            st["vpt"] = float(st["vpt"]) + vv * ((cf - prev_c) / prev_c)
        if cf is not None:
            st["prev_c"] = cf
        return float(st["vpt"])

    def _builtin_ta_emv(self, args: list[Any]) -> float | None:
        """Ease of Movement.

        ta.emv(length)
        Measures ease of price movement relative to volume.
        """
        unary = 1
        if len(args) < unary:
            msg = "ta.emv() requires 1 argument: length"
            self._error(msg)

        length = self._expect_int(args[0], "length must be integer")

        if length < unary:
            msg = "EMV length must be >= 1"
            self._error(msg)

        if self._use_incremental_ta():
            return self._emv_inc_update(
                self._context_source("high"),
                self._context_source("low"),
                self._context_source("volume"),
                length,
            )

        highs = (getattr(self, "current_series", None) or {}).get("high", [])
        lows = (getattr(self, "current_series", None) or {}).get("low", [])
        volumes = (getattr(self, "current_series", None) or {}).get("volume", [])

        if not highs or not lows or not volumes or len(highs) < length:
            return None

        return self._emv(highs, lows, volumes, length)

    def _builtin_ta_iii(self, args: list[Any]) -> float | None:
        """Intraday Intensity Index - measures money flow without volume data.

        Forms:
        - ``ta.iii`` / ``ta.iii()`` — chart high/low/close
        - ``ta.iii(high, low, close)`` — explicit values/series (current bar)
        """
        if len(args) == 0:
            highs = self._context_series("high")
            lows = self._context_series("low")
            closes = self._context_series("close")
            if not highs or not lows or not closes:
                return None
            high = highs[-1]
            low = lows[-1]
            close = closes[-1]
        elif len(args) >= TERNARY:
            high = args[0][-1] if isinstance(args[0], list) and args[0] else args[0]
            low = args[1][-1] if isinstance(args[1], list) and args[1] else args[1]
            close = args[2][-1] if isinstance(args[2], list) and args[2] else args[2]
            high = self._expect_number(high, "high must be numeric")
            low = self._expect_number(low, "low must be numeric")
            close = self._expect_number(close, "close must be numeric")
        else:
            self._error("ta.iii() requires 0 or 3 arguments: high, low, close")
            return None

        if high is None or low is None or close is None:
            return None
        try:
            high_f = float(high)
            low_f = float(low)
            close_f = float(close)
        except (TypeError, ValueError):
            return None

        tr = high_f - low_f
        if tr == 0:
            return 0.0

        iii = 2 * close_f - high_f - low_f
        return iii / tr if tr != 0 else 0.0

    def _builtin_ta_nvi(self, args: list[Any]) -> Any:
        """Negative Volume Index - cumulative index when volume decreases.

        Forms:
        - ``ta.nvi`` / ``ta.nvi()`` — chart close + volume
        - ``ta.nvi(close, volume)`` — explicit series
        """
        if self._use_incremental_ta():
            if len(args) == 0:
                closes = self._context_source("close")
                volumes = self._context_source("volume")
                if not volumes:
                    volumes = 0.0
            elif len(args) >= BINARY:
                closes = self._as_series_or_raw(args[0], last_sample_ok=True)
                volumes = self._as_series_or_raw(args[1], last_sample_ok=True)
            else:
                self._error("ta.nvi() requires 0 or 2+ arguments: close, volume")
                return None
            return self._nvi_inc_update(closes, volumes)
        if len(args) == 0:
            close_series = self._context_series("close")
            volume_series = self._context_series("volume") or [0.0] * len(close_series)
        elif len(args) >= BINARY:
            close_series = self._as_series(args[0])
            volume_series = self._as_series(args[1])
        else:
            self._error("ta.nvi() requires 0 or 2+ arguments: close, volume")
            return []

        if len(close_series) != len(volume_series):
            return [None]

        nvi_values = []
        nvi = 1000.0

        for i in range(len(close_series)):
            if i == 0:
                nvi_values.append(nvi)
                continue

            if close_series[i - 1] != 0:
                close_change = (close_series[i] - close_series[i - 1]) / close_series[i - 1]
            else:
                close_change = 0
            vol = volume_series[i] if isinstance(volume_series[i], (int, float)) else 0

            prev_vol = volume_series[i - 1] if i > 0 and isinstance(volume_series[i - 1], (int, float)) else 0
            if vol < prev_vol:
                nvi = nvi * (1 + close_change)

            nvi_values.append(nvi)

        return nvi_values

    def _builtin_ta_pvi(self, args: list[Any]) -> Any:
        """Positive Volume Index - cumulative index when volume increases.

        Forms:
        - ``ta.pvi`` / ``ta.pvi()`` — chart close + volume
        - ``ta.pvi(close, volume)`` — explicit series
        """
        if self._use_incremental_ta():
            if len(args) == 0:
                closes = self._context_source("close")
                volumes = self._context_source("volume")
                if not volumes:
                    volumes = 0.0
            elif len(args) >= BINARY:
                closes = self._as_series_or_raw(args[0], last_sample_ok=True)
                volumes = self._as_series_or_raw(args[1], last_sample_ok=True)
            else:
                self._error("ta.pvi() requires 0 or 2+ arguments: close, volume")
                return None
            return self._pvi_inc_update(closes, volumes)
        if len(args) == 0:
            close_series = self._context_series("close")
            volume_series = self._context_series("volume") or [0.0] * len(close_series)
        elif len(args) >= BINARY:
            close_series = self._as_series(args[0])
            volume_series = self._as_series(args[1])
        else:
            self._error("ta.pvi() requires 0 or 2+ arguments: close, volume")
            return []

        if len(close_series) != len(volume_series):
            return [None]

        pvi_values = []
        pvi = 1000.0

        for i in range(len(close_series)):
            if i == 0:
                pvi_values.append(pvi)
                continue

            if close_series[i - 1] != 0:
                close_change = (close_series[i] - close_series[i - 1]) / close_series[i - 1]
            else:
                close_change = 0
            vol = volume_series[i] if isinstance(volume_series[i], (int, float)) else 0
            prev_vol = volume_series[i - 1] if i > 0 and isinstance(volume_series[i - 1], (int, float)) else 0

            if vol > prev_vol:
                pvi = pvi * (1 + close_change)

            pvi_values.append(pvi)

        return pvi_values

    def _builtin_ta_voi(self, args: list[Any]) -> float:
        """Volume of Imbalance.

        ta.voi(buy_volume, sell_volume)
        Measures imbalance in buy vs sell volume.
        """
        if len(args) < BINARY:
            msg = "ta.voi() requires 2 arguments: buy_volume, sell_volume"
            self._error(msg)

        buy_vol = float(args[0]) if isinstance(args[0], (int, float)) else 0.0
        sell_vol = float(args[1]) if isinstance(args[1], (int, float)) else 0.0

        total = buy_vol + sell_vol
        if total == 0:
            return 0.0

        voi_value = (buy_vol - sell_vol) / total
        return voi_value

    def _builtin_ta_bid_ask_imbalance(self, args: list[Any]) -> dict[str, float]:
        """Bid-Ask Imbalance.

        ta.bid_ask_imbalance(bid_size, ask_size, bid_price, ask_price)
        Measures market microstructure imbalance.
        """
        if len(args) < QUATERNARY:
            msg = "ta.bid_ask_imbalance() requires 4 arguments: bid_size, ask_size, bid_price, ask_price"
            self._error(msg)

        bid_size = float(args[0]) if isinstance(args[0], (int, float)) else 0.0
        ask_size = float(args[1]) if isinstance(args[1], (int, float)) else 0.0
        bid_price = float(args[2]) if isinstance(args[2], (int, float)) else 0.0
        ask_price = float(args[3]) if isinstance(args[3], (int, float)) else 0.0

        total_size = bid_size + ask_size
        if total_size == 0:
            return {"imbalance_ratio": 0.0, "spread": 0.0}

        imbalance = (bid_size - ask_size) / total_size
        spread = ask_price - bid_price if bid_price > 0 else 0.0

        return {"imbalance_ratio": imbalance, "spread": spread}

    def _builtin_ta_volume_weighted_momentum(self, args: list[Any]) -> float | None:
        """Volume Weighted Momentum.

        ta.volume_weighted_momentum(series, volume, length)
        Returns: Momentum value weighted by volume
        """
        if len(args) < TERNARY:
            msg = "ta.volume_weighted_momentum() requires 3 arguments: series, volume, length"
            self._error(msg)

        length = self._expect_int(args[2], "length must be integer")
        if self._use_incremental_ta():
            return self._volume_weighted_momentum_inc_update(
                self._as_series_or_raw(args[0], last_sample_ok=True),
                self._as_series_or_raw(args[1], last_sample_ok=True),
                length,
            )

        series = self._as_series(args[0])
        volume = self._as_series(args[1])

        if len(series) < length or len(volume) < length:
            return None

        momentum_sum = 0.0
        volume_sum = 0.0

        for i in range(length):
            idx = -1 - i
            if idx - 1 < -len(series):
                break

            price_change = series[idx] - series[idx - 1]
            vol = volume[idx] if isinstance(volume[idx], (int, float)) else 0.0

            momentum_sum += price_change * vol
            volume_sum += vol

        return momentum_sum / volume_sum if volume_sum > 0 else 0.0

    # -- Implementation helpers (private _method prefix) --------------------

    def _obv(self, closes: list[float], volumes: list[float]) -> int:
        """Calculate On-Balance Volume."""
        warmup_length = 3
        if len(closes) != len(volumes) or len(closes) < warmup_length:
            return 0
        obv = 0
        for idx in range(2, len(closes)):
            if closes[idx] > closes[idx - 1]:
                obv += volumes[idx]
            elif closes[idx] < closes[idx - 1]:
                obv -= volumes[idx]
        return obv

    def _mfi(
        self,
        highs: list[float],
        lows: list[float],
        closes: list[float],
        volumes: list[float],
        period: int,
    ) -> float:
        """Calculate Money Flow Index (reference Pine / numba_mfi parity).

        Needs ``period + 1`` typical-price samples (direction vs previous bar).
        Returns na until ready; 100 when only positive MF, 0 when only negative.
        Equal typical prices contribute to neither side.
        """
        n = min(len(highs), len(lows), len(closes), len(volumes))
        if period < 1 or n <= period:
            return math.nan
        highs = highs[-n:]
        lows = lows[-n:]
        closes = closes[-n:]
        volumes = volumes[-n:]
        i = n - 1

        def _tp(k: int) -> float | None:
            h, lo, c = highs[k], lows[k], closes[k]
            if not isinstance(h, (int, float)) or not isinstance(lo, (int, float)) or not isinstance(c, (int, float)):
                return None
            return (float(h) + float(lo) + float(c)) / 3.0

        pos = 0.0
        neg = 0.0
        for j in range(period):
            k = i - j
            tp = _tp(k)
            tp_prev = _tp(k - 1)
            if tp is None or tp_prev is None:
                return math.nan
            vol = volumes[k]
            if not isinstance(vol, (int, float)):
                return math.nan
            mf = tp * float(vol)
            if tp > tp_prev:
                pos += mf
            elif tp < tp_prev:
                neg += mf
        if neg == 0.0:
            if pos == 0.0:
                return 50.0
            return 100.0
        ratio = pos / neg
        return 100.0 - (100.0 / (1.0 + ratio))

    def _accdist(
        self,
        high_series: list[Any],
        low_series: list[Any],
        close_series: list[Any],
        volume_series: list[Any],
    ) -> list[float | None]:
        """Calculate Accumulation/Distribution Index."""
        ad_values = []
        ad = 0.0

        for i in range(len(close_series)):
            high = high_series[i] if i < len(high_series) else 0
            low = low_series[i] if i < len(low_series) else 0
            close = close_series[i] if i < len(close_series) else 0
            vol = volume_series[i] if i < len(volume_series) else 0

            if high == low:
                clv = 0.0
            else:
                clv = ((close - low) - (high - close)) / (high - low)

            ad += clv * vol
            ad_values.append(ad)

        return ad_values

    def _wad(
        self,
        high_series: list[Any],
        low_series: list[Any],
        close_series: list[Any],
        volume_series: list[Any],
    ) -> list[float | None]:
        """Calculate Williams Accumulation/Distribution."""
        wad_values = []
        wad = 0.0

        for i in range(len(close_series)):
            if i == 0:
                wad_values.append(0.0)
                continue

            high = high_series[i] if i < len(high_series) else close_series[i]
            low = low_series[i] if i < len(low_series) else close_series[i]
            close = close_series[i] if i < len(close_series) else 0
            prev_close = close_series[i - 1] if i > 0 and i - 1 < len(close_series) else 0
            vol = volume_series[i] if i < len(volume_series) else 0

            if close > prev_close:
                wad += vol * (close - low)
            elif close < prev_close:
                wad -= vol * (high - close)

            wad_values.append(wad)

        return wad_values

    def _wvad(
        self,
        high_series: list[Any],
        low_series: list[Any],
        close_series: list[Any],
        volume_series: list[Any],
        period: int,
    ) -> list[float | None]:
        """Calculate Williams Volume Accumulation/Distribution."""
        # First get raw WAD
        wad_values = self._wad(high_series, low_series, close_series, volume_series)

        # Get total volume over period
        wvad_values = []
        for i in range(len(wad_values)):
            start_idx = max(0, i - period + 1)
            volume_sum = sum(v for v in volume_series[start_idx : i + 1] if isinstance(v, (int, float)))

            if volume_sum > 0:
                wvad = wad_values[i] / volume_sum if wad_values[i] is not None else 0.0
            else:
                wvad = 0.0

            wvad_values.append(wvad)

        return wvad_values

    def _cmf(
        self,
        close_series: list[Any],
        high_series: list[Any],
        low_series: list[Any],
        volume_series: list[Any],
        period: int,
    ) -> list[float | None]:
        """Calculate Chaikin Money Flow."""
        cmf_values = []
        for i in range(len(close_series)):
            start_idx = max(0, i - period + 1)

            clv_sum = 0.0
            vol_sum = 0.0

            for j in range(start_idx, i + 1):
                high_val = high_series[j] if j < len(high_series) else 0
                low_val = low_series[j] if j < len(low_series) else 0
                close_val = close_series[j] if j < len(close_series) else 0
                volume_val = volume_series[j] if j < len(volume_series) else 0

                hl_range = high_val - low_val
                if hl_range != 0:
                    clv = ((close_val - low_val) - (high_val - close_val)) / hl_range
                else:
                    clv = 0.0

                clv_sum += clv * volume_val
                vol_sum += volume_val

            cmf = clv_sum / vol_sum if vol_sum > 0 else 0.0
            cmf_values.append(cmf)

        return cmf_values

    def _klinger(
        self,
        close_series: list[Any],
        volume_series: list[Any],
        fast_period: int,
        slow_period: int,
    ) -> list[float | None]:
        """Calculate Klinger Oscillator."""
        # Calculate true range volume
        trv_values = []
        for i in range(len(close_series)):
            if i == 0:
                trv = 0.0
            else:
                close_val = close_series[i] if i < len(close_series) else 0
                prev_close = close_series[i - 1] if i > 0 else 0
                volume_val = volume_series[i] if i < len(volume_series) else 0

                if close_val > prev_close:
                    trv = volume_val
                elif close_val < prev_close:
                    trv = -volume_val
                else:
                    trv = 0.0

            trv_values.append(trv)

        # Calculate fast and slow EMAs of cumulative TRV
        cumsum_trv = []
        cum = 0.0
        for trv in trv_values:
            cum += trv
            cumsum_trv.append(cum)

        fast_ema = self._ema(cumsum_trv, fast_period)
        slow_ema = self._ema(cumsum_trv, slow_period)

        ko_values: list[float | None] = []
        for i in range(len(fast_ema)):
            if fast_ema[i] is None or slow_ema[i] is None:
                ko_values.append(None)
            else:
                ko_values.append(fast_ema[i] - slow_ema[i])

        return ko_values

    def _apo(self, series: list[Any], fast: int, slow: int) -> list[float | None]:
        """Calculate Absolute Price Oscillator."""
        fast_ema = self._ema(series, fast)
        slow_ema = self._ema(series, slow)

        apo_values: list[float | None] = []
        for i in range(len(series)):
            if fast_ema[i] is None or slow_ema[i] is None:
                apo_values.append(None)
            else:
                apo_values.append(fast_ema[i] - slow_ema[i])

        return apo_values

    def _vpt(self, closes: list[Any], volumes: list[Any]) -> float | None:
        """Cumulative Volume Price Trend (last value).

        ``VPT = previous VPT + volume * (close - prev_close) / prev_close``.
        Bar 0 is ``0.0`` (matches compile ``numba_pvt_inc``).
        """
        if not closes:
            return None
        n = min(len(closes), len(volumes) if volumes else 0)
        if n <= 0:
            return None
        vpt = 0.0
        if n == 1:
            return 0.0
        for i in range(1, n):
            prev_close = closes[i - 1]
            close = closes[i]
            vol = volumes[i]
            if prev_close is None or close is None:
                continue
            try:
                prev_f = float(prev_close)
                close_f = float(close)
                vol_f = 0.0 if vol is None else float(vol)
            except (TypeError, ValueError):
                continue
            if prev_f != prev_f or close_f != close_f:
                continue
            if prev_f == 0.0:
                continue
            if vol_f != vol_f:
                vol_f = 0.0
            vpt = vpt + vol_f * ((close_f - prev_f) / prev_f)
        return vpt

    def _emv(
        self,
        highs: list[Any],
        lows: list[Any],
        volumes: list[Any],
        length: int,
    ) -> float | None:
        """Calculate Ease of Movement."""
        emv_vals: list[float | None] = []
        for i in range(len(highs)):
            if i == 0 or volumes[i] == 0:
                emv_vals.append(None)
                continue

            distance_moved = ((highs[i] + lows[i]) / 2.0) - ((highs[i - 1] + lows[i - 1]) / 2.0)
            box_height = highs[i] - lows[i]

            if box_height == 0:
                emv_vals.append(None)
            else:
                emv = (distance_moved / box_height) * (highs[i] - lows[i]) / volumes[i] if volumes[i] != 0 else 0
                emv_vals.append(emv)

        valid_emv = [v for v in emv_vals if v is not None]
        if not valid_emv or len(valid_emv) < length:
            return None

        emv_sma = sum(valid_emv[-length:]) / length
        return emv_sma
