# Copyright (C) 2024-2026 jango_blockchained
#
# This file is part of pynescript.
#
# pynescript is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# pynescript is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with pynescript.  If not, see <https://www.gnu.org/licenses/>.
#
# SPDX-License-Identifier: AGPL-3.0-or-later

"""Pine Script evaluator builtins package (dispatch aggregate).

Implements Pine built-in functions organized by category mixins and register
functions, composed into :class:`BuiltinEvaluator`:

- **Numeric** — ``math.*``, bare abs/max/min/…
- **String** — ``str.*``, ``tostring`` / ``tonumber``
- **Array / Matrix / Map** — collection namespaces
- **Technical** — ``ta.*`` (via :mod:`technical` + submodules)
- **Plotting / Drawing** — ``plot*``, ``line``/``box``/``label``/``table``
- **Strategy** — ``strategy.*`` execution + constants
- **Request / Input / Utility** — data fetch, parameters, time helpers
- **Color / Ticker / Timeframe / Logging / Declarations** — registered
  function tables (not always mixins)
- **Alerts** — ``alert`` / ``alertcondition``

Mixin composition
-----------------
Category mixins subclass :class:`~.base.BuiltinDispatchMixin` and expose
``_*_builtin_map()``. :class:`BuiltinEvaluator._build_builtin_map` merges
those maps and calls ``register_*_functions`` for non-mixin namespaces.
Expression evaluation resolves names through ``_call_builtin``.
"""

from __future__ import annotations

from typing import NoReturn

from .alerts import AlertsMixin
from .arrays import ArrayBuiltinsMixin
from .base import BuiltinHandler
from .color import register_color_functions
from .declarations import register_script_declaration_functions
from .drawing import DrawingBuiltinsMixin
from .input import InputBuiltinsMixin
from .logging import register_logging_functions
from .map_evaluator import MapBuiltinsMixin
from .matrix_evaluator import MatrixBuiltinsMixin
from .numeric import NumericBuiltinsMixin
from .plotting import PlottingFunctionsMixin
from .request import FootprintBuiltinsMixin
from .request import RequestBuiltinsMixin
from .strategy import StrategyBuiltinsMixin
from .strategy_constants import StrategyConstantsMixin
from .strings import StringBuiltinsMixin
from .technical import TechnicalAnalysisMixin
from .ticker import register_ticker_functions
from .timeframe import register_timeframe_functions
from .utility import UtilityFunctionsMixin


class BuiltinEvaluator(
    AlertsMixin,
    NumericBuiltinsMixin,
    StringBuiltinsMixin,
    ArrayBuiltinsMixin,
    TechnicalAnalysisMixin,
    PlottingFunctionsMixin,
    UtilityFunctionsMixin,
    InputBuiltinsMixin,
    RequestBuiltinsMixin,
    FootprintBuiltinsMixin,
    DrawingBuiltinsMixin,
    StrategyBuiltinsMixin,
    StrategyConstantsMixin,
    MatrixBuiltinsMixin,
    MapBuiltinsMixin,
):
    """Compose all builtin mixins and registration helpers into one dispatcher.

    Inherits category mixins; :meth:`_build_builtin_map` merges each
    ``_*_builtin_map()`` and wires script-declaration side effects (drawing
    limits, strategy declaration application).
    """

    def _build_builtin_map(self) -> dict[str, BuiltinHandler]:
        dispatch = super()._build_builtin_map()
        dispatch.update(self._alerts_builtin_map())
        dispatch.update(self._numeric_builtin_map())
        dispatch.update(self._string_builtin_map())
        dispatch.update(self._array_builtin_map())
        dispatch.update(self._technical_builtin_map())
        dispatch.update(self._plotting_builtin_map())
        dispatch.update(self._utility_builtin_map())
        dispatch.update(self._input_builtin_map())
        dispatch.update(self._request_builtin_map())
        dispatch.update(self._footprint_builtin_map())
        dispatch.update(self._drawing_builtin_map())
        dispatch.update(self._strategy_builtin_map())
        dispatch.update(self._strategy_constants_builtin_map())
        dispatch.update(self._matrix_builtin_map())
        dispatch.update(self._map_builtin_map())
        # Register Phase 5 functions
        register_ticker_functions(dispatch)
        register_logging_functions(dispatch)
        register_color_functions(dispatch)
        register_timeframe_functions(dispatch)
        register_script_declaration_functions(dispatch)
        # Capture indicator()/strategy()/library() → evaluator._script_declaration
        # so runtimes can expose overlay + title in the API response.
        for _name in ("indicator", "study", "strategy", "library"):
            _raw = dispatch.get(_name)
            if _raw is None:
                continue

            def _decl_handler(
                args: list,
                kwargs: dict | None = None,
                *,
                _raw_fn=_raw,
                _self=self,
                _is_strategy=_name == "strategy",
            ):
                # Script declaration is constant — skip re-build after bar 0
                # (Runtime sets ``_pine_defs_locked`` after the first visit).
                if getattr(_self, "_pine_defs_locked", False):
                    existing = getattr(_self, "_script_declaration", None)
                    if existing is not None:
                        return existing
                decl = _raw_fn(args, kwargs)
                try:
                    _self._script_declaration = decl  # type: ignore[attr-defined]
                except Exception:  # noqa: BLE001 — setattr on frozen/partial mocks
                    pass
                # Wire max_lines/labels/boxes/polylines_count → DrawingRegistry GC.
                try:
                    from .drawing import DrawingRegistry

                    DrawingRegistry.configure_from_declaration(decl)
                except Exception:  # noqa: BLE001 — drawings optional in partial hosts
                    pass
                if _is_strategy and hasattr(_self, "_apply_strategy_declaration"):
                    # Fail closed on programming errors (TypeError/AttributeError/
                    # ValueError) so bad strategy() kwargs surface in the bar loop
                    # rather than leaving StrategyState silently misconfigured.
                    try:
                        _self._apply_strategy_declaration(decl)
                    except (TypeError, AttributeError, ValueError):
                        raise
                    except Exception:  # noqa: BLE001 — optional host plumbing only
                        pass
                return decl

            dispatch[_name] = _decl_handler
        return dispatch

    @staticmethod
    def _error(message: str) -> NoReturn:
        """Raise a ValueError with the given message.

        Required because BuiltinEvaluator is instantiated directly in tests
        and needs to handle errors without BaseEvaluator's implementation.
        """
        raise ValueError(message)
